import '../../../../core/constants/enums.dart';
import '../../domain/entities/school.dart';
import '../../domain/entities/environment.dart';
import '../../domain/entities/wall.dart';
import '../../domain/entities/measurement.dart';
import '../../domain/entities/photo.dart';
import '../../domain/entities/detected_item.dart';
import '../../domain/entities/pathology.dart';
import '../../domain/entities/checklist_item.dart';

/// Conversores (Data Mappers) entre entidades de dominio e Map<String,Object?>
/// usados pelo sqflite. Mantem a persistencia isolada do dominio.
///
/// Convencao: enums sao gravados pelo indice (`.index`) para robustez e
/// performance. Booleans viram 0/1.

// ----------------------- School -----------------------
extension SchoolMapper on School {
  Map<String, Object?> toMap() => {
        'id': id,
        'name': name,
        'address': address,
        'latitude': latitude,
        'longitude': longitude,
        'director': director,
        'phone': phone,
        'inspector': inspector,
        'visit_date': visitDate.toIso8601String(),
        'process_number': processNumber,
        'survey_type': surveyType.index,
        'synced': synced ? 1 : 0,
        'updated_at': DateTime.now().toIso8601String(),
      };
}

School schoolFromMap(Map<String, Object?> m) => School(
      id: m['id'] as String,
      name: m['name'] as String? ?? '',
      address: m['address'] as String? ?? '',
      latitude: (m['latitude'] as num?)?.toDouble() ?? 0,
      longitude: (m['longitude'] as num?)?.toDouble() ?? 0,
      director: m['director'] as String? ?? '',
      phone: m['phone'] as String? ?? '',
      inspector: m['inspector'] as String? ?? '',
      visitDate:
          DateTime.tryParse(m['visit_date'] as String? ?? '') ?? DateTime.now(),
      processNumber: m['process_number'] as String? ?? '',
      surveyType: SurveyType.values[(m['survey_type'] as int?) ?? 0],
      synced: (m['synced'] as int? ?? 0) == 1,
    );

// ----------------------- Environment -----------------------
extension EnvironmentMapper on Environment {
  Map<String, Object?> toMap() => {
        'id': id,
        'school_id': schoolId,
        'code': code,
        'type': type.index,
        'name': name,
        'floor_area_m2': floorAreaM2,
        'ceiling_has_lining': ceilingHasLining ? 1 : 0,
        'updated_at': DateTime.now().toIso8601String(),
      };
}

Environment environmentFromMap(
  Map<String, Object?> m,
  List<Wall> walls,
) =>
    Environment(
      id: m['id'] as String,
      schoolId: m['school_id'] as String,
      code: m['code'] as String? ?? '',
      type: EnvironmentType.values[(m['type'] as int?) ?? 0],
      name: m['name'] as String? ?? '',
      floorAreaM2: (m['floor_area_m2'] as num?)?.toDouble() ?? 0,
      ceilingHasLining: (m['ceiling_has_lining'] as int? ?? 1) == 1,
      walls: walls,
    );

// ----------------------- Wall -----------------------
extension WallMapper on Wall {
  Map<String, Object?> toMap() => {
        'id': id,
        'environment_id': environmentId,
        'label': label,
        'width_m': measurement.widthM,
        'height_m': measurement.heightM,
        'openings_area_m2': openingsAreaM2,
        'has_baseboard': hasBaseboard ? 1 : 0,
        'has_tiles': hasTiles ? 1 : 0,
        'tile_height_m': tileHeightM,
        'confidence': measurement.confidence.index,
        'confidence_score': measurement.confidenceScore,
        'source': measurement.source,
      };
}

Wall wallFromMap(Map<String, Object?> m) => Wall(
      id: m['id'] as String,
      environmentId: m['environment_id'] as String,
      label: m['label'] as String? ?? '',
      openingsAreaM2: (m['openings_area_m2'] as num?)?.toDouble() ?? 0,
      hasBaseboard: (m['has_baseboard'] as int? ?? 1) == 1,
      hasTiles: (m['has_tiles'] as int? ?? 0) == 1,
      tileHeightM: (m['tile_height_m'] as num?)?.toDouble() ?? 0,
      measurement: Measurement(
        widthM: (m['width_m'] as num?)?.toDouble() ?? 0,
        heightM: (m['height_m'] as num?)?.toDouble() ?? 0,
        confidence: ConfidenceLevel.values[(m['confidence'] as int?) ?? 3],
        confidenceScore: (m['confidence_score'] as num?)?.toDouble() ?? 0,
        source: m['source'] as String? ?? 'manual',
      ),
    );

// ----------------------- Photo -----------------------
extension PhotoMapper on Photo {
  Map<String, Object?> toMap() => {
        'id': id,
        'environment_id': environmentId,
        'local_path': localPath,
        'cloud_url': cloudUrl,
        'category': category.index,
        'caption': caption,
        'note': note,
        'latitude': latitude,
        'longitude': longitude,
        'taken_at': takenAt?.toIso8601String(),
        'synced': 0,
      };
}

Photo photoFromMap(Map<String, Object?> m) => Photo(
      id: m['id'] as String,
      environmentId: m['environment_id'] as String,
      localPath: m['local_path'] as String? ?? '',
      cloudUrl: m['cloud_url'] as String?,
      category: PhotoCategory.values[(m['category'] as int?) ?? 4],
      caption: m['caption'] as String? ?? '',
      note: m['note'] as String? ?? '',
      latitude: (m['latitude'] as num?)?.toDouble(),
      longitude: (m['longitude'] as num?)?.toDouble(),
      takenAt: DateTime.tryParse(m['taken_at'] as String? ?? ''),
    );

// ----------------------- DetectedItem -----------------------
extension ItemMapper on DetectedItem {
  Map<String, Object?> toMap() => {
        'id': id,
        'environment_id': environmentId,
        'type': type.index,
        'quantity': quantity,
        'confidence': confidence.index,
        'confidence_score': confidenceScore,
        'manually_confirmed': manuallyConfirmed ? 1 : 0,
      };
}

DetectedItem itemFromMap(Map<String, Object?> m) => DetectedItem(
      id: m['id'] as String,
      environmentId: m['environment_id'] as String,
      type: ItemType.values[(m['type'] as int?) ?? 0],
      quantity: (m['quantity'] as int?) ?? 0,
      confidence: ConfidenceLevel.values[(m['confidence'] as int?) ?? 3],
      confidenceScore: (m['confidence_score'] as num?)?.toDouble() ?? 0,
      manuallyConfirmed: (m['manually_confirmed'] as int? ?? 0) == 1,
    );

// ----------------------- Pathology -----------------------
extension PathologyMapper on Pathology {
  Map<String, Object?> toMap() => {
        'id': id,
        'environment_id': environmentId,
        'type': type.index,
        'severity': severity,
        'confidence': confidence.index,
        'description': description,
        'photo_id': photoId,
      };
}

Pathology pathologyFromMap(Map<String, Object?> m) => Pathology(
      id: m['id'] as String,
      environmentId: m['environment_id'] as String,
      type: PathologyType.values[(m['type'] as int?) ?? 0],
      severity: (m['severity'] as int?) ?? 1,
      confidence: ConfidenceLevel.values[(m['confidence'] as int?) ?? 3],
      description: m['description'] as String? ?? '',
      photoId: m['photo_id'] as String?,
    );

// ----------------------- ChecklistItem -----------------------
extension ChecklistMapper on ChecklistItem {
  Map<String, Object?> toMap() => {
        'id': id,
        'environment_id': environmentId,
        'subject': subject,
        'state': state.index,
        'note': note,
      };
}

ChecklistItem checklistFromMap(Map<String, Object?> m) => ChecklistItem(
      id: m['id'] as String,
      environmentId: m['environment_id'] as String,
      subject: m['subject'] as String? ?? '',
      state: ConservationState.values[(m['state'] as int?) ?? 0],
      note: m['note'] as String? ?? '',
    );
