import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import '../../../../core/constants/app_constants.dart';

/// Banco de dados local (SQLite) - base do funcionamento offline (requisito 20).
///
/// Estrutura hierarquica (requisito 19):
///   Escolas -> Ambientes -> Paredes / Fotos / Itens / Patologias / Checklist
///
/// Todas as tabelas possuem `synced` (0/1) e `updated_at` para dar suporte a
/// sincronizacao incremental com o Firebase (requisito 21).
class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();

  Database? _db;

  Future<Database> get database async {
    _db ??= await _open();
    return _db!;
  }

  Future<Database> _open() async {
    final dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, AppConstants.dbName);
    return openDatabase(
      path,
      version: AppConstants.dbVersion,
      onConfigure: (db) async {
        // Habilita chaves estrangeiras (integridade referencial).
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: _createSchema,
    );
  }

  Future<void> _createSchema(Database db, int version) async {
    await db.execute('''
      CREATE TABLE schools (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        address TEXT,
        latitude REAL,
        longitude REAL,
        director TEXT,
        phone TEXT,
        inspector TEXT,
        visit_date TEXT,
        process_number TEXT,
        survey_type INTEGER,
        synced INTEGER DEFAULT 0,
        updated_at TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE environments (
        id TEXT PRIMARY KEY,
        school_id TEXT NOT NULL,
        code TEXT NOT NULL,
        type INTEGER,
        name TEXT,
        floor_area_m2 REAL DEFAULT 0,
        ceiling_has_lining INTEGER DEFAULT 1,
        synced INTEGER DEFAULT 0,
        updated_at TEXT,
        FOREIGN KEY (school_id) REFERENCES schools (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE walls (
        id TEXT PRIMARY KEY,
        environment_id TEXT NOT NULL,
        label TEXT,
        width_m REAL,
        height_m REAL,
        openings_area_m2 REAL DEFAULT 0,
        has_baseboard INTEGER DEFAULT 1,
        has_tiles INTEGER DEFAULT 0,
        tile_height_m REAL DEFAULT 0,
        confidence INTEGER,
        confidence_score REAL,
        source TEXT,
        FOREIGN KEY (environment_id) REFERENCES environments (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE photos (
        id TEXT PRIMARY KEY,
        environment_id TEXT NOT NULL,
        local_path TEXT,
        cloud_url TEXT,
        category INTEGER,
        caption TEXT,
        note TEXT,
        latitude REAL,
        longitude REAL,
        taken_at TEXT,
        synced INTEGER DEFAULT 0,
        FOREIGN KEY (environment_id) REFERENCES environments (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE items (
        id TEXT PRIMARY KEY,
        environment_id TEXT NOT NULL,
        type INTEGER,
        quantity INTEGER,
        confidence INTEGER,
        confidence_score REAL,
        manually_confirmed INTEGER DEFAULT 0,
        FOREIGN KEY (environment_id) REFERENCES environments (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE pathologies (
        id TEXT PRIMARY KEY,
        environment_id TEXT NOT NULL,
        type INTEGER,
        severity INTEGER,
        confidence INTEGER,
        description TEXT,
        photo_id TEXT,
        FOREIGN KEY (environment_id) REFERENCES environments (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE checklist (
        id TEXT PRIMARY KEY,
        environment_id TEXT NOT NULL,
        subject TEXT,
        state INTEGER,
        note TEXT,
        FOREIGN KEY (environment_id) REFERENCES environments (id) ON DELETE CASCADE
      )
    ''');

    // Indices para performance com muitos registros (requisito 25).
    await db.execute(
        'CREATE INDEX idx_env_school ON environments (school_id)');
    await db
        .execute('CREATE INDEX idx_wall_env ON walls (environment_id)');
    await db
        .execute('CREATE INDEX idx_photo_env ON photos (environment_id)');
  }
}
