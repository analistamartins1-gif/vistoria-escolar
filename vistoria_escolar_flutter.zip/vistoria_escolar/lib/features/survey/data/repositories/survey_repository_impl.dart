import 'package:sqflite/sqflite.dart';

import '../../domain/entities/school.dart';
import '../../domain/entities/environment.dart';
import '../../domain/entities/wall.dart';
import '../../domain/entities/photo.dart';
import '../../domain/entities/detected_item.dart';
import '../../domain/entities/pathology.dart';
import '../../domain/entities/checklist_item.dart';
import '../../domain/repositories/survey_repository.dart';
import '../datasources/app_database.dart';
import '../models/mappers.dart';

/// Implementacao offline-first do [SurveyRepository] usando SQLite.
///
/// Todas as escritas usam `ConflictAlgorithm.replace` (upsert) e marcam o
/// registro como nao sincronizado, para que o SyncService envie depois.
class SurveyRepositoryImpl implements SurveyRepository {
  SurveyRepositoryImpl(this._dbProvider);

  final AppDatabase _dbProvider;

  Future<Database> get _db => _dbProvider.database;

  // ----------------- Escolas -----------------
  @override
  Future<List<School>> getSchools() async {
    final db = await _db;
    final rows = await db.query('schools', orderBy: 'name');
    return rows.map(schoolFromMap).toList();
  }

  @override
  Future<School?> getSchool(String id) async {
    final db = await _db;
    final rows = await db.query('schools', where: 'id = ?', whereArgs: [id]);
    return rows.isEmpty ? null : schoolFromMap(rows.first);
  }

  @override
  Future<void> saveSchool(School school) async {
    final db = await _db;
    await db.insert(
      'schools',
      school.copyWith(synced: false).toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  @override
  Future<void> deleteSchool(String id) async {
    final db = await _db;
    // ON DELETE CASCADE remove ambientes/paredes/fotos vinculados.
    await db.delete('schools', where: 'id = ?', whereArgs: [id]);
  }

  // ----------------- Ambientes -----------------
  @override
  Future<List<Environment>> getEnvironments(String schoolId) async {
    final db = await _db;
    final rows = await db.query('environments',
        where: 'school_id = ?', whereArgs: [schoolId], orderBy: 'code');
    final result = <Environment>[];
    for (final row in rows) {
      final walls = await getWalls(row['id'] as String);
      result.add(environmentFromMap(row, walls));
    }
    return result;
  }

  @override
  Future<void> saveEnvironment(Environment environment) async {
    final db = await _db;
    await db.insert('environments', environment.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // ----------------- Paredes -----------------
  @override
  Future<List<Wall>> getWalls(String environmentId) async {
    final db = await _db;
    final rows = await db.query('walls',
        where: 'environment_id = ?', whereArgs: [environmentId]);
    return rows.map(wallFromMap).toList();
  }

  @override
  Future<void> saveWall(Wall wall) async {
    final db = await _db;
    await db.insert('walls', wall.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // ----------------- Fotos -----------------
  @override
  Future<List<Photo>> getPhotos(String environmentId) async {
    final db = await _db;
    final rows = await db.query('photos',
        where: 'environment_id = ?', whereArgs: [environmentId]);
    return rows.map(photoFromMap).toList();
  }

  @override
  Future<void> savePhoto(Photo photo) async {
    final db = await _db;
    await db.insert('photos', photo.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // ----------------- Itens -----------------
  @override
  Future<List<DetectedItem>> getItems(String environmentId) async {
    final db = await _db;
    final rows = await db.query('items',
        where: 'environment_id = ?', whereArgs: [environmentId]);
    return rows.map(itemFromMap).toList();
  }

  @override
  Future<void> saveItem(DetectedItem item) async {
    final db = await _db;
    await db.insert('items', item.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // ----------------- Patologias -----------------
  @override
  Future<List<Pathology>> getPathologies(String environmentId) async {
    final db = await _db;
    final rows = await db.query('pathologies',
        where: 'environment_id = ?', whereArgs: [environmentId]);
    return rows.map(pathologyFromMap).toList();
  }

  @override
  Future<void> savePathology(Pathology pathology) async {
    final db = await _db;
    await db.insert('pathologies', pathology.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // ----------------- Checklist -----------------
  @override
  Future<List<ChecklistItem>> getChecklist(String environmentId) async {
    final db = await _db;
    final rows = await db.query('checklist',
        where: 'environment_id = ?', whereArgs: [environmentId]);
    return rows.map(checklistFromMap).toList();
  }

  @override
  Future<void> saveChecklistItem(ChecklistItem item) async {
    final db = await _db;
    await db.insert('checklist', item.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // ----------------- Sincronizacao -----------------
  @override
  Future<List<School>> getUnsyncedSchools() async {
    final db = await _db;
    final rows = await db.query('schools', where: 'synced = 0');
    return rows.map(schoolFromMap).toList();
  }

  @override
  Future<void> markSchoolSynced(String id) async {
    final db = await _db;
    await db.update('schools', {'synced': 1},
        where: 'id = ?', whereArgs: [id]);
  }
}
