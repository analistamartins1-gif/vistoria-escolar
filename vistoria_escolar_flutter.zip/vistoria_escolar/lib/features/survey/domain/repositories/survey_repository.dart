import '../entities/school.dart';
import '../entities/environment.dart';
import '../entities/wall.dart';
import '../entities/photo.dart';
import '../entities/detected_item.dart';
import '../entities/pathology.dart';
import '../entities/checklist_item.dart';

/// Contrato da camada de dados (Dependency Inversion Principle).
///
/// A camada de apresentacao/dominio depende desta abstracao, nunca de
/// SQLite ou Firebase diretamente. Permite trocar a implementacao e testar
/// com mocks.
abstract interface class SurveyRepository {
  // -------- Escolas --------
  Future<List<School>> getSchools();
  Future<School?> getSchool(String id);
  Future<void> saveSchool(School school);
  Future<void> deleteSchool(String id);

  // -------- Ambientes --------
  Future<List<Environment>> getEnvironments(String schoolId);
  Future<void> saveEnvironment(Environment environment);

  // -------- Paredes --------
  Future<List<Wall>> getWalls(String environmentId);
  Future<void> saveWall(Wall wall);

  // -------- Fotos --------
  Future<List<Photo>> getPhotos(String environmentId);
  Future<void> savePhoto(Photo photo);

  // -------- Itens detectados --------
  Future<List<DetectedItem>> getItems(String environmentId);
  Future<void> saveItem(DetectedItem item);

  // -------- Patologias --------
  Future<List<Pathology>> getPathologies(String environmentId);
  Future<void> savePathology(Pathology pathology);

  // -------- Checklist --------
  Future<List<ChecklistItem>> getChecklist(String environmentId);
  Future<void> saveChecklistItem(ChecklistItem item);

  // -------- Sincronizacao --------
  Future<List<School>> getUnsyncedSchools();
  Future<void> markSchoolSynced(String id);
}
