import 'package:equatable/equatable.dart';
import '../../../../core/constants/enums.dart';

/// Manifestacao patologica identificada (requisito 11).
class Pathology extends Equatable {
  const Pathology({
    required this.id,
    required this.environmentId,
    required this.type,
    required this.severity,
    required this.confidence,
    this.description = '',
    this.photoId,
  });

  final String id;
  final String environmentId;
  final PathologyType type;

  /// Gravidade estimada (1 = leve, 5 = critica). Alimenta a analise de risco.
  final int severity;
  final ConfidenceLevel confidence;
  final String description;

  /// Foto associada (evidencia).
  final String? photoId;

  @override
  List<Object?> get props => [id, environmentId, type, severity];
}
