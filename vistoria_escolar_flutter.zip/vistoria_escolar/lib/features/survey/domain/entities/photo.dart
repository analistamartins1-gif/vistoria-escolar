import 'package:equatable/equatable.dart';

/// Categoria da foto (requisito 8).
enum PhotoCategory { antes, depois, detalhe, patologia, geral }

/// Foto vinculada a um ambiente. Armazenada localmente; caminho em nuvem
/// preenchido apos sincronizacao.
class Photo extends Equatable {
  const Photo({
    required this.id,
    required this.environmentId,
    required this.localPath,
    required this.category,
    this.caption = '',
    this.note = '',
    this.latitude,
    this.longitude,
    this.cloudUrl,
    this.takenAt,
  });

  final String id;
  final String environmentId;
  final String localPath;
  final PhotoCategory category;
  final String caption;
  final String note;

  /// Georreferenciamento da foto (requisito Modo IA).
  final double? latitude;
  final double? longitude;
  final String? cloudUrl;
  final DateTime? takenAt;

  @override
  List<Object?> get props => [id, environmentId, localPath, category];
}
