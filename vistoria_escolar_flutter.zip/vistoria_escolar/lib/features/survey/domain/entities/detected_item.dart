import 'package:equatable/equatable.dart';
import '../../../../core/constants/enums.dart';

/// Item detectado pela IA no ambiente (requisito 5) ou adicionado manualmente.
class DetectedItem extends Equatable {
  const DetectedItem({
    required this.id,
    required this.environmentId,
    required this.type,
    required this.quantity,
    required this.confidence,
    this.confidenceScore = 0,
    this.manuallyConfirmed = false,
  });

  final String id;
  final String environmentId;
  final ItemType type;
  final int quantity;
  final ConfidenceLevel confidence;
  final double confidenceScore;

  /// True quando o usuario confirmou/editou a deteccao (requisito 7).
  final bool manuallyConfirmed;

  DetectedItem copyWith({int? quantity, bool? manuallyConfirmed}) =>
      DetectedItem(
        id: id,
        environmentId: environmentId,
        type: type,
        quantity: quantity ?? this.quantity,
        confidence: manuallyConfirmed == true
            ? ConfidenceLevel.manual
            : confidence,
        confidenceScore: confidenceScore,
        manuallyConfirmed: manuallyConfirmed ?? this.manuallyConfirmed,
      );

  @override
  List<Object?> get props => [id, environmentId, type, quantity];
}
