import 'package:equatable/equatable.dart';
import '../../../../core/constants/enums.dart';

/// Escola vistoriada (requisito 1). Cadastrada antes da visita.
class School extends Equatable {
  const School({
    required this.id,
    required this.name,
    required this.address,
    required this.latitude,
    required this.longitude,
    required this.director,
    required this.phone,
    required this.inspector,
    required this.visitDate,
    required this.processNumber,
    required this.surveyType,
    this.synced = false,
  });

  final String id;
  final String name;
  final String address;
  final double latitude;
  final double longitude;
  final String director;
  final String phone;

  /// Responsavel pela visita.
  final String inspector;
  final DateTime visitDate;

  /// Numero do processo administrativo.
  final String processNumber;
  final SurveyType surveyType;

  /// Flag de sincronizacao com a nuvem (requisito 21).
  final bool synced;

  School copyWith({bool? synced}) => School(
        id: id,
        name: name,
        address: address,
        latitude: latitude,
        longitude: longitude,
        director: director,
        phone: phone,
        inspector: inspector,
        visitDate: visitDate,
        processNumber: processNumber,
        surveyType: surveyType,
        synced: synced ?? this.synced,
      );

  @override
  List<Object?> get props => [id, name, processNumber, synced];
}
