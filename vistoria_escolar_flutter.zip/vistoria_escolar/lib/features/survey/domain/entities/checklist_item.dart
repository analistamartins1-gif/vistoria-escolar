import 'package:equatable/equatable.dart';
import '../../../../core/constants/enums.dart';

/// Item de checklist de conservacao (requisito 12).
/// Ex.: Pintura -> Boa/Regular/Ruim.
class ChecklistItem extends Equatable {
  const ChecklistItem({
    required this.id,
    required this.environmentId,
    required this.subject,
    required this.state,
    this.note = '',
  });

  final String id;
  final String environmentId;

  /// Elemento avaliado: "Pintura", "Piso", "Cobertura", etc.
  final String subject;
  final ConservationState state;
  final String note;

  @override
  List<Object?> get props => [id, environmentId, subject, state];
}
