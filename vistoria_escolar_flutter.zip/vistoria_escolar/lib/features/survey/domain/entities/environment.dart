import 'package:equatable/equatable.dart';
import '../../../../core/constants/enums.dart';
import 'wall.dart';

/// Ambiente vistoriado (requisito 2). Agrega paredes, piso e forro.
class Environment extends Equatable {
  const Environment({
    required this.id,
    required this.schoolId,
    required this.code,
    required this.type,
    required this.walls,
    this.floorAreaM2 = 0,
    this.ceilingHasLining = true,
    this.name = '',
  });

  final String id;
  final String schoolId;

  /// Codigo do ambiente, ex.: "SALA 01", "BANHEIRO FEM." (requisito 2).
  final String code;
  final EnvironmentType type;
  final List<Wall> walls;

  /// Area de piso medida (m²). Tambem usada como area de forro base.
  final double floorAreaM2;

  /// Possui forro? (se nao, area de forro = 0).
  final bool ceilingHasLining;
  final String name;

  Environment copyWith({List<Wall>? walls, double? floorAreaM2}) => Environment(
        id: id,
        schoolId: schoolId,
        code: code,
        type: type,
        walls: walls ?? this.walls,
        floorAreaM2: floorAreaM2 ?? this.floorAreaM2,
        ceilingHasLining: ceilingHasLining,
        name: name,
      );

  @override
  List<Object?> get props => [id, schoolId, code, type];
}
