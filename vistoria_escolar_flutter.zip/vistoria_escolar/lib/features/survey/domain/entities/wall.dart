import 'package:equatable/equatable.dart';
import 'measurement.dart';

/// Parede de um ambiente (requisito 3/4). Base do calculo de pintura,
/// revestimento e rodape.
class Wall extends Equatable {
  const Wall({
    required this.id,
    required this.environmentId,
    required this.label,
    required this.measurement,
    this.openingsAreaM2 = 0,
    this.hasBaseboard = true,
    this.hasTiles = false,
    this.tileHeightM = 0,
  });

  final String id;
  final String environmentId;

  /// Ex.: "Parede Norte", "P1".
  final String label;
  final Measurement measurement;

  /// Area total de aberturas (portas/janelas) a descontar da pintura (m²).
  final double openingsAreaM2;

  /// Possui rodape? (afeta calculo de comprimento de rodape)
  final bool hasBaseboard;

  /// Possui revestimento ceramico (azulejo)?
  final bool hasTiles;

  /// Altura do revestimento ceramico a partir do piso (m), se houver.
  final double tileHeightM;

  /// Area liquida de pintura = area bruta - aberturas (nunca negativa).
  double get netPaintAreaM2 {
    final net = measurement.areaM2 - openingsAreaM2;
    return net < 0 ? 0 : (net * 100).round() / 100;
  }

  @override
  List<Object?> get props => [id, environmentId, label, measurement];
}
