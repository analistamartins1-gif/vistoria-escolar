import 'package:equatable/equatable.dart';
import '../../../../core/constants/enums.dart';

/// Uma medicao (largura/altura/area) de uma superficie.
///
/// Sempre carrega um [ConfidenceLevel]. Conforme a recomendacao tecnica,
/// medicoes por camera/AR sao ESTIMATIVAS: a UI deve exibir a confianca e
/// permitir edicao manual antes de usar em orcamento/contratacao publica.
class Measurement extends Equatable {
  const Measurement({
    required this.widthM,
    required this.heightM,
    required this.confidence,
    this.confidenceScore = 0,
    this.source = 'ar',
  });

  /// Largura em metros.
  final double widthM;

  /// Altura em metros.
  final double heightM;

  /// Nivel de confianca (alta/media/baixa/manual).
  final ConfidenceLevel confidence;

  /// Score bruto retornado pelo AR/IA (0..1), quando disponivel.
  final double confidenceScore;

  /// Origem: 'ar', 'mlkit', 'manual', 'planta'.
  final String source;

  double get areaM2 => (widthM * heightM * 100).round() / 100;
  double get perimeterM => (2 * (widthM + heightM) * 100).round() / 100;

  /// Retorna copia validada manualmente (marca como confianca maxima).
  Measurement validatedManually(double w, double h) => Measurement(
        widthM: w,
        heightM: h,
        confidence: ConfidenceLevel.manual,
        confidenceScore: 1,
        source: 'manual',
      );

  Measurement copyWith({
    double? widthM,
    double? heightM,
    ConfidenceLevel? confidence,
    double? confidenceScore,
    String? source,
  }) =>
      Measurement(
        widthM: widthM ?? this.widthM,
        heightM: heightM ?? this.heightM,
        confidence: confidence ?? this.confidence,
        confidenceScore: confidenceScore ?? this.confidenceScore,
        source: source ?? this.source,
      );

  @override
  List<Object?> get props =>
      [widthM, heightM, confidence, confidenceScore, source];
}
