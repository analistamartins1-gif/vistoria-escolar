import 'package:equatable/equatable.dart';

/// Quantitativos calculados de um ambiente (requisitos 6 e 13).
///
/// Todos os valores derivam das medicoes das paredes e do piso/forro.
/// Objeto imutavel produzido pelo QuantificationEngine.
class Quantities extends Equatable {
  const Quantities({
    required this.paintAreaM2,
    required this.plasterAreaM2,
    required this.tileAreaM2,
    required this.floorAreaM2,
    required this.ceilingAreaM2,
    required this.baseboardLengthM,
    required this.puttyKg,
    required this.sealerLiters,
    required this.paintLiters,
    required this.doors,
    required this.windows,
    required this.lights,
    required this.switches,
    required this.outlets,
    required this.fans,
  });

  final double paintAreaM2; // area de pintura
  final double plasterAreaM2; // area de reboco
  final double tileAreaM2; // area de revestimento ceramico
  final double floorAreaM2; // area de piso
  final double ceilingAreaM2; // area de forro
  final double baseboardLengthM; // comprimento de rodape

  final double puttyKg; // massa corrida (kg)
  final double sealerLiters; // selador (L)
  final double paintLiters; // tinta (L)

  final int doors;
  final int windows;
  final int lights;
  final int switches;
  final int outlets;
  final int fans;

  Map<String, Object> toReportRows() => {
        'Area de pintura (m2)': paintAreaM2,
        'Area de reboco (m2)': plasterAreaM2,
        'Area de revestimento (m2)': tileAreaM2,
        'Area de piso (m2)': floorAreaM2,
        'Area de forro (m2)': ceilingAreaM2,
        'Rodape (m)': baseboardLengthM,
        'Massa corrida (kg)': puttyKg,
        'Selador (L)': sealerLiters,
        'Tinta (L)': paintLiters,
        'Portas': doors,
        'Janelas': windows,
        'Luminarias': lights,
        'Interruptores': switches,
        'Tomadas': outlets,
        'Ventiladores': fans,
      };

  @override
  List<Object?> get props => [
        paintAreaM2,
        floorAreaM2,
        ceilingAreaM2,
        baseboardLengthM,
        paintLiters,
      ];
}
