import '../../../../core/constants/enums.dart';
import '../entities/pathology.dart';
import '../entities/checklist_item.dart';

/// Nivel de prioridade/urgencia sugerido pela IA.
enum Priority { baixa, media, alta, critica }

/// Uma recomendacao tecnica gerada a partir do levantamento (requisito 16).
class ServiceSuggestion {
  const ServiceSuggestion({
    required this.service,
    required this.priority,
    required this.risk,
    required this.rationale,
    this.estimatedUsefulLifeYears,
  });

  final String service; // ex.: "Tratamento de infiltracao + repintura"
  final Priority priority; // prioridade/urgencia
  final String risk; // descricao do risco
  final String rationale; // justificativa tecnica
  final int? estimatedUsefulLifeYears; // vida util estimada apos intervencao
}

/// Use case que transforma patologias + checklist em recomendacoes de
/// servicos, prioridade, risco e urgencia.
///
/// Baseado em regras (rule-based). Em uma versao avancada, este e o ponto de
/// integracao com um modelo multimodal (Claude/Gemini) para gerar o memorial
/// descritivo preliminar. Mantido como regras deterministicas para
/// rastreabilidade tecnica (importante em contratacao publica).
class SuggestServices {
  const SuggestServices();

  List<ServiceSuggestion> call({
    required List<Pathology> pathologies,
    required List<ChecklistItem> checklist,
  }) {
    final out = <ServiceSuggestion>[];

    // 1) Regras por patologia.
    for (final p in pathologies) {
      out.add(_fromPathology(p));
    }

    // 2) Regras por checklist em estado "ruim".
    for (final c in checklist.where((c) => c.state == ConservationState.ruim)) {
      out.add(
        ServiceSuggestion(
          service: 'Recuperacao de ${c.subject.toLowerCase()}',
          priority: Priority.alta,
          risk: 'Elemento em estado ruim: ${c.subject}.',
          rationale:
              'Checklist classificou "${c.subject}" como RUIM. Intervencao '
              'recomendada para restabelecer condicoes de uso.',
          estimatedUsefulLifeYears: 8,
        ),
      );
    }

    // Ordena por prioridade (critica primeiro).
    out.sort((a, b) => b.priority.index.compareTo(a.priority.index));
    return out;
  }

  ServiceSuggestion _fromPathology(Pathology p) {
    return switch (p.type) {
      PathologyType.infiltracao => const ServiceSuggestion(
          service: 'Impermeabilizacao e tratamento de infiltracao',
          priority: Priority.alta,
          risk: 'Comprometimento de revestimentos, mofo e risco eletrico.',
          rationale:
              'Infiltracao ativa acelera a degradacao e afeta a salubridade '
              'do ambiente escolar.',
          estimatedUsefulLifeYears: 10,
        ),
      PathologyType.trinca => ServiceSuggestion(
          service: 'Investigacao estrutural e tratamento de trinca',
          priority: p.severity >= 4 ? Priority.critica : Priority.alta,
          risk: 'Possivel origem estrutural; risco a seguranca.',
          rationale:
              'Trincas com gravidade ${p.severity}/5 exigem avaliacao '
              'estrutural antes de intervencao esteticas.',
          estimatedUsefulLifeYears: 15,
        ),
      PathologyType.corrosao => const ServiceSuggestion(
          service: 'Tratamento de armadura exposta / corrosao',
          priority: Priority.critica,
          risk: 'Perda de secao de armadura e risco de colapso localizado.',
          rationale:
              'Corrosao de armadura reduz a capacidade estrutural e deve ser '
              'tratada com prioridade maxima.',
          estimatedUsefulLifeYears: 20,
        ),
      PathologyType.coberturaComprometida => const ServiceSuggestion(
          service: 'Reforma de cobertura / telhado',
          priority: Priority.critica,
          risk: 'Infiltracoes generalizadas e risco de desabamento.',
          rationale: 'Cobertura comprometida gera danos em cascata.',
          estimatedUsefulLifeYears: 15,
        ),
      PathologyType.mofo || PathologyType.bolor => const ServiceSuggestion(
          service: 'Limpeza, tratamento fungicida e repintura',
          priority: Priority.media,
          risk: 'Problemas respiratorios em alunos e funcionarios.',
          rationale: 'Mofo/bolor indicam umidade; tratar a causa e a superficie.',
          estimatedUsefulLifeYears: 5,
        ),
      PathologyType.pinturaDescascando => const ServiceSuggestion(
          service: 'Raspagem, massa corrida, selador e repintura',
          priority: Priority.media,
          risk: 'Degradacao progressiva do substrato.',
          rationale: 'Pintura descascando expoe o reboco a umidade.',
          estimatedUsefulLifeYears: 5,
        ),
      PathologyType.ceramicaSolta || PathologyType.pisoQuebrado =>
        const ServiceSuggestion(
          service: 'Substituicao de revestimento/piso danificado',
          priority: Priority.alta,
          risk: 'Risco de queda e acidentes.',
          rationale: 'Piso/revestimento danificado e risco de acidente escolar.',
          estimatedUsefulLifeYears: 10,
        ),
      _ => ServiceSuggestion(
          service: 'Reparo de ${p.type.name}',
          priority: p.severity >= 4 ? Priority.alta : Priority.media,
          risk: 'Degradacao do elemento afetado.',
          rationale: 'Manifestacao patologica registrada na vistoria.',
          estimatedUsefulLifeYears: 8,
        ),
    };
  }
}
