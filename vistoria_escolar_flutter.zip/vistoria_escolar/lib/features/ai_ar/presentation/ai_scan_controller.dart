import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../../../core/constants/enums.dart';
import '../../../core/di/injection.dart';
import '../../survey/domain/entities/environment.dart';
import '../../survey/domain/entities/wall.dart';
import '../../survey/domain/entities/measurement.dart';
import '../../survey/domain/entities/detected_item.dart';
import '../../survey/domain/entities/pathology.dart';
import '../../survey/domain/entities/quantities.dart';
import '../services/object_detection_service.dart';
import '../services/pathology_detection_service.dart';

/// Etapas do fluxo "Modo IA" (recomendacao do usuario):
/// 1 classificar ambiente, 2 medir paredes/piso, 3 detectar itens,
/// 4 detectar patologias, 5 quantificar, 6 revisar/confirmar.
enum ScanStage {
  identifyingEnvironment,
  measuring,
  detectingItems,
  detectingPathologies,
  quantifying,
  review,
}

/// Estado imutavel da sessao de varredura por IA.
class AiScanState {
  const AiScanState({
    this.stage = ScanStage.identifyingEnvironment,
    this.suggestedType,
    this.typeConfidence = 0,
    this.walls = const [],
    this.items = const [],
    this.pathologies = const [],
    this.quantities,
    this.busy = false,
    this.error,
  });

  final ScanStage stage;
  final EnvironmentType? suggestedType;
  final double typeConfidence;
  final List<Wall> walls;
  final List<DetectedItem> items;
  final List<Pathology> pathologies;
  final Quantities? quantities;
  final bool busy;
  final String? error;

  /// True se ha qualquer medida com confianca baixa: a UI destaca para
  /// conferencia manual com trena (contratacao publica).
  bool get hasLowConfidence => walls.any(
        (w) => w.measurement.confidence == ConfidenceLevel.baixa,
      );

  AiScanState copyWith({
    ScanStage? stage,
    EnvironmentType? suggestedType,
    double? typeConfidence,
    List<Wall>? walls,
    List<DetectedItem>? items,
    List<Pathology>? pathologies,
    Quantities? quantities,
    bool? busy,
    String? error,
  }) =>
      AiScanState(
        stage: stage ?? this.stage,
        suggestedType: suggestedType ?? this.suggestedType,
        typeConfidence: typeConfidence ?? this.typeConfidence,
        walls: walls ?? this.walls,
        items: items ?? this.items,
        pathologies: pathologies ?? this.pathologies,
        quantities: quantities ?? this.quantities,
        busy: busy ?? this.busy,
        error: error,
      );
}

/// Orquestra o pipeline do Modo IA, combinando os servicos de IA/AR e o
/// motor de quantificacao. Mantem a tela "burra" (apenas renderiza estado).
class AiScanController extends StateNotifier<AiScanState> {
  AiScanController(this._ref, this.schoolId) : super(const AiScanState());

  final Ref _ref;
  final String schoolId;
  final _uuid = const Uuid();

  /// Passo 1: define o tipo de ambiente sugerido pela IA (confirmado na UI).
  void setEnvironmentSuggestion(EnvironmentType type, double confidence) {
    state = state.copyWith(
      suggestedType: type,
      typeConfidence: confidence,
      stage: ScanStage.measuring,
    );
  }

  /// Passo 2: adiciona uma parede medida (por AR ou manual).
  void addWall(Measurement m, {String? label}) {
    final wall = Wall(
      id: _uuid.v4(),
      environmentId: '', // atribuido ao salvar o ambiente
      label: label ?? 'Parede ${state.walls.length + 1}',
      measurement: m,
    );
    state = state.copyWith(walls: [...state.walls, wall]);
  }

  /// Permite corrigir manualmente uma medida (requisito 7). Marca como manual.
  void editWall(int index, double width, double height) {
    final walls = [...state.walls];
    final old = walls[index];
    walls[index] = Wall(
      id: old.id,
      environmentId: old.environmentId,
      label: old.label,
      openingsAreaM2: old.openingsAreaM2,
      hasBaseboard: old.hasBaseboard,
      hasTiles: old.hasTiles,
      tileHeightM: old.tileHeightM,
      measurement: old.measurement.validatedManually(width, height),
    );
    state = state.copyWith(walls: walls);
  }

  /// Passo 3: consolida deteccoes de itens em contagens editaveis.
  void applyItemDetections(List<ItemCount> counts) {
    final items = counts
        .map(
          (c) => DetectedItem(
            id: _uuid.v4(),
            environmentId: '',
            type: c.type,
            quantity: c.quantity,
            confidence: c.level,
            confidenceScore: c.avgConfidence,
          ),
        )
        .toList();
    state = state.copyWith(
      items: items,
      stage: ScanStage.detectingPathologies,
    );
  }

  /// Passo 4: adiciona sugestoes de patologia confirmadas.
  void applyPathologies(List<PathologySuggestion> suggestions) {
    final paths = suggestions
        .map(
          (s) => Pathology(
            id: _uuid.v4(),
            environmentId: '',
            type: s.type,
            severity: s.severityHint,
            confidence: s.level,
          ),
        )
        .toList();
    state =
        state.copyWith(pathologies: paths, stage: ScanStage.quantifying);
  }

  /// Passo 5: roda o motor de quantificacao sobre o que foi levantado.
  void computeQuantities({double floorAreaM2 = 0}) {
    final engine = _ref.read(quantificationEngineProvider);
    final env = Environment(
      id: 'tmp',
      schoolId: schoolId,
      code: 'TMP',
      type: state.suggestedType ?? EnvironmentType.outros,
      walls: state.walls,
      floorAreaM2: floorAreaM2,
    );
    final q = engine.compute(env, state.items);
    state = state.copyWith(quantities: q, stage: ScanStage.review);
  }
}

/// Provider familiar por escola (permite varreduras independentes).
final aiScanControllerProvider = StateNotifierProvider.autoDispose
    .family<AiScanController, AiScanState, String>(
  (ref, schoolId) => AiScanController(ref, schoolId),
);
