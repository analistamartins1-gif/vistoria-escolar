import 'package:flutter/material.dart';
import '../../../../core/constants/enums.dart';

/// Selo visual que comunica o nivel de confianca de uma medida/deteccao.
/// Verde = alta, ambar = media, vermelho = baixa, azul = manual validada.
class ConfidenceBadge extends StatelessWidget {
  const ConfidenceBadge({required this.level, super.key});
  final ConfidenceLevel level;

  @override
  Widget build(BuildContext context) {
    final (color, icon) = switch (level) {
      ConfidenceLevel.alta => (Colors.green, Icons.verified),
      ConfidenceLevel.media => (Colors.amber, Icons.info_outline),
      ConfidenceLevel.baixa => (Colors.red, Icons.error_outline),
      ConfidenceLevel.manual => (Colors.blue, Icons.edit),
    };
    return Chip(
      avatar: Icon(icon, color: Colors.white, size: 18),
      backgroundColor: color,
      label: Text(
        'Confianca: ${level.label}',
        style: const TextStyle(color: Colors.white),
      ),
    );
  }
}
