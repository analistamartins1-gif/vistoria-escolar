import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/constants/enums.dart';
import 'ai_scan_controller.dart';
import 'widgets/confidence_badge.dart';

/// Tela do "Modo IA" (recomendacao principal do usuario).
///
/// O engenheiro percorre o ambiente com a camera e o app conduz o fluxo em
/// etapas. Aqui montamos a estrutura de UI e o overlay de AR; a integracao
/// com o widget de camera/AR do plugin entra no [_ArViewport].
///
/// IMPORTANTE (contratacao publica): o rodape sempre exibe o aviso de que as
/// medidas por camera sao estimativas e devem ser conferidas com trena.
class ArScanScreen extends ConsumerWidget {
  const ArScanScreen({required this.schoolId, super.key});

  final String schoolId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(aiScanControllerProvider(schoolId));
    final controller = ref.read(aiScanControllerProvider(schoolId).notifier);

    return Scaffold(
      appBar: AppBar(title: Text('Modo IA - ${_stageLabel(state.stage)}')),
      body: Column(
        children: [
          Expanded(child: _ArViewport(state: state)),
          _StageControls(state: state, controller: controller),
          const _EstimateDisclaimer(),
        ],
      ),
    );
  }

  static String _stageLabel(ScanStage s) => switch (s) {
        ScanStage.identifyingEnvironment => 'Identificando ambiente',
        ScanStage.measuring => 'Medindo',
        ScanStage.detectingItems => 'Detectando itens',
        ScanStage.detectingPathologies => 'Detectando patologias',
        ScanStage.quantifying => 'Quantificando',
        ScanStage.review => 'Revisao',
      };
}

/// Placeholder do viewport de camera/AR. Em producao, embute o widget do
/// ar_flutter_plugin (ARView) com overlay das medidas em tempo real.
class _ArViewport extends StatelessWidget {
  const _ArViewport({required this.state});
  final AiScanState state;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black87,
      alignment: Alignment.center,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.view_in_ar, size: 96, color: Colors.white54),
          const SizedBox(height: 12),
          const Text(
            'Aponte a camera para a parede',
            style: TextStyle(color: Colors.white70),
          ),
          if (state.walls.isNotEmpty) ...[
            const SizedBox(height: 16),
            // Overlay estilo "Parede 4,12 m x 2,95 m / Area 12,15 m2".
            _MeasurementOverlay(wall: state.walls.last),
          ],
        ],
      ),
    );
  }
}

class _MeasurementOverlay extends StatelessWidget {
  const _MeasurementOverlay({required this.wall});
  final dynamic wall;

  @override
  Widget build(BuildContext context) {
    final m = wall.measurement;
    return Card(
      color: Colors.white,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Text(
              '${m.widthM.toStringAsFixed(2)} m  x  '
              '${m.heightM.toStringAsFixed(2)} m',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            Text('Area: ${m.areaM2.toStringAsFixed(2)} m2'),
            const SizedBox(height: 6),
            ConfidenceBadge(level: m.confidence),
          ],
        ),
      ),
    );
  }
}

/// Botoes grandes que avancam o fluxo por etapa.
class _StageControls extends StatelessWidget {
  const _StageControls({required this.state, required this.controller});
  final AiScanState state;
  final AiScanController controller;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: switch (state.stage) {
        ScanStage.identifyingEnvironment => ElevatedButton.icon(
            icon: const Icon(Icons.center_focus_strong),
            label: const Text('Confirmar ambiente'),
            // Em producao viria do classificador; aqui exemplo.
            onPressed: () => controller.setEnvironmentSuggestion(
              state.suggestedType ?? EnvironmentType.salaDeAula,
              state.typeConfidence,
            ),
          ),
        ScanStage.measuring => ElevatedButton.icon(
            icon: const Icon(Icons.straighten),
            label: const Text('Concluir medicao e detectar itens'),
            onPressed: () => controller.applyItemDetections(const []),
          ),
        ScanStage.detectingItems => const SizedBox.shrink(),
        ScanStage.detectingPathologies => ElevatedButton.icon(
            icon: const Icon(Icons.warning_amber),
            label: const Text('Confirmar patologias'),
            onPressed: () => controller.applyPathologies(const []),
          ),
        ScanStage.quantifying => ElevatedButton.icon(
            icon: const Icon(Icons.calculate),
            label: const Text('Calcular quantitativos'),
            onPressed: () => controller.computeQuantities(),
          ),
        ScanStage.review => FilledButton.icon(
            icon: const Icon(Icons.check_circle),
            label: const Text('Salvar ambiente'),
            onPressed: () => Navigator.of(context).pop(state),
          ),
      },
    );
  }
}

/// Aviso permanente exigido pela boa pratica de contratacao publica.
class _EstimateDisclaimer extends StatelessWidget {
  const _EstimateDisclaimer();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: Theme.of(context).colorScheme.tertiaryContainer,
      padding: const EdgeInsets.all(10),
      child: Text(
        'Medidas por camera sao ESTIMATIVAS. Confira com trena/planta antes '
        'de usar em orcamento ou contratacao publica.',
        style: Theme.of(context).textTheme.bodySmall,
        textAlign: TextAlign.center,
      ),
    );
  }
}
