import '../../survey/domain/entities/environment.dart';
import '../../survey/domain/entities/detected_item.dart';
import '../../survey/domain/entities/quantities.dart';
import '../../../core/constants/enums.dart';

/// Coeficientes tecnicos (rendimentos e perdas) usados na quantificacao.
///
/// Sao ESTIMATIVAS de projeto/orcamento preliminar. Devem ser conferidas
/// com as fichas tecnicas dos materiais e tabelas de referencia (SINAPI/SICRO)
/// antes de uso em contratacao publica. Todos parametrizados para ajuste.
class QuantificationParams {
  const QuantificationParams({
    this.paintCoats = 2,
    this.paintYieldM2PerLiter = 10.0, // por demao
    this.sealerYieldM2PerLiter = 8.0, // 1 demao
    this.puttyKgPerM2PerCoat = 0.45,
    this.puttyCoats = 2,
    this.wasteFactorFloor = 0.10, // 10% de perda em piso/revestimento
    this.wasteFactorTile = 0.10,
  });

  final int paintCoats;
  final double paintYieldM2PerLiter;
  final double sealerYieldM2PerLiter;
  final double puttyKgPerM2PerCoat;
  final int puttyCoats;
  final double wasteFactorFloor;
  final double wasteFactorTile;
}

/// Motor de quantificacao automatica (requisitos 6 e 13).
///
/// Recebe um [Environment] (com paredes medidas) e a lista de itens
/// detectados, e devolve [Quantities] com areas, comprimentos e consumo
/// de materiais. E Dart puro => 100% testavel sem dispositivo.
class QuantificationEngine {
  const QuantificationEngine({this.params = const QuantificationParams()});

  final QuantificationParams params;

  Quantities compute(Environment env, List<DetectedItem> items) {
    // ---- Areas de parede ----
    // Bruta = soma das areas das paredes.
    // Liquida (pintura) = bruta - aberturas (portas/janelas).
    var grossWall = 0.0;
    var netPaint = 0.0;
    var tileArea = 0.0;
    var baseboard = 0.0;

    for (final wall in env.walls) {
      grossWall += wall.measurement.areaM2;
      netPaint += wall.netPaintAreaM2;

      if (wall.hasTiles && wall.tileHeightM > 0) {
        tileArea += wall.measurement.widthM * wall.tileHeightM;
      }
      if (wall.hasBaseboard) {
        // Rodape corre ao longo da base da parede (largura).
        baseboard += wall.measurement.widthM;
      }
    }

    // Reboco: area de alvenaria a revestir. Simplificacao adotada:
    // reboco ~ area liquida de parede (bruta menos aberturas).
    final plasterArea = netPaint;

    // ---- Piso e forro ----
    final floor = env.floorAreaM2;
    final ceiling = env.ceilingHasLining ? env.floorAreaM2 : 0.0;

    // ---- Consumo de materiais de pintura ----
    final paintLiters = _round2(
      (netPaint * params.paintCoats) / params.paintYieldM2PerLiter,
    );
    final sealerLiters =
        _round2(netPaint / params.sealerYieldM2PerLiter);
    final puttyKg = _round2(
      netPaint * params.puttyKgPerM2PerCoat * params.puttyCoats,
    );

    // ---- Contagem de itens (a partir da deteccao/edicao) ----
    int count(ItemType t) => items
        .where((i) => i.type == t)
        .fold(0, (sum, i) => sum + i.quantity);

    return Quantities(
      paintAreaM2: _round2(netPaint),
      plasterAreaM2: _round2(plasterArea),
      tileAreaM2: _round2(tileArea * (1 + params.wasteFactorTile)),
      floorAreaM2: _round2(floor * (1 + params.wasteFactorFloor)),
      ceilingAreaM2: _round2(ceiling),
      baseboardLengthM: _round2(baseboard),
      puttyKg: puttyKg,
      sealerLiters: sealerLiters,
      paintLiters: paintLiters,
      doors: count(ItemType.porta),
      windows: count(ItemType.janela),
      lights: count(ItemType.luminaria),
      switches: count(ItemType.interruptor),
      outlets: count(ItemType.tomada),
      fans: count(ItemType.ventilador),
    );
  }

  static double _round2(double v) => (v * 100).round() / 100;
}
