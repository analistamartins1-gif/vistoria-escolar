/// Converte observacoes de voz em texto (requisito 10) - FASE 2.
///
/// Stub sem dependencia nativa para manter o build limpo. A integracao real
/// usa o pacote `speech_to_text` (reconhecimento on-device pt-BR): descomente
/// a dependencia no pubspec.yaml e implemente os TODO(prod) ao ativar.
class SpeechToTextService {
  bool _listening = false;

  Future<bool> initialize() async {
    // TODO(prod): SpeechToText().initialize()
    return false;
  }

  /// Inicia a escuta; chamaria [onResult] com o texto reconhecido.
  Future<void> start(void Function(String text, bool isFinal) onResult) async {
    // TODO(prod): SpeechToText().listen(localeId: 'pt_BR', onResult: ...)
  }

  Future<void> stop() async {
    _listening = false;
  }

  bool get isListening => _listening;
}
