import 'package:speech_to_text/speech_to_text.dart';

/// Converte observacoes de voz em texto (requisito 10).
///
/// Ex.: "A infiltracao ocorre apenas em periodo chuvoso." -> texto anexado
/// ao ambiente. Usa o reconhecimento on-device do sistema (pt-BR).
class SpeechToTextService {
  final SpeechToText _stt = SpeechToText();
  bool _available = false;

  Future<bool> initialize() async {
    _available = await _stt.initialize();
    return _available;
  }

  /// Inicia a escuta; chama [onResult] com o texto reconhecido (parcial/final).
  Future<void> start(void Function(String text, bool isFinal) onResult) async {
    if (!_available) return;
    await _stt.listen(
      localeId: 'pt_BR',
      onResult: (r) => onResult(r.recognizedWords, r.finalResult),
    );
  }

  Future<void> stop() => _stt.stop();
  bool get isListening => _stt.isListening;
}
