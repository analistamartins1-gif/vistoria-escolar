import '../../../core/constants/enums.dart';

/// Uma deteccao bruta retornada pelo detector de objetos.
class RawDetection {
  const RawDetection(this.label, this.confidence, this.boundingBox);
  final String label;
  final double confidence; // 0..1
  final List<double> boundingBox; // [left, top, right, bottom]
}

/// Resultado consolidado por tipo de item (requisito 5 e 13).
class ItemCount {
  const ItemCount(this.type, this.quantity, this.avgConfidence);
  final ItemType type;
  final int quantity;
  final double avgConfidence;

  ConfidenceLevel get level => avgConfidence >= 0.75
      ? ConfidenceLevel.alta
      : avgConfidence >= 0.5
          ? ConfidenceLevel.media
          : ConfidenceLevel.baixa;
}

/// Servico de deteccao de itens construtivos usando Google ML Kit
/// (Object Detection) + um modelo customizado TFLite treinado para
/// portas, janelas, luminarias, tomadas, interruptores, etc.
///
/// Aqui isolamos a logica de mapeamento label->ItemType e a contagem, que
/// e testavel sem camera. A captura de frames vem da tela AR/Camera.
class ObjectDetectionService {
  /// Mapa dos rotulos do modelo (pt) para o enum de dominio.
  static const Map<String, ItemType> _labelMap = {
    'porta': ItemType.porta,
    'janela': ItemType.janela,
    'quadro': ItemType.quadro,
    'pilar': ItemType.pilar,
    'viga': ItemType.viga,
    'luminaria': ItemType.luminaria,
    'ventilador': ItemType.ventilador,
    'tomada': ItemType.tomada,
    'interruptor': ItemType.interruptor,
    'extintor': ItemType.extintor,
    'bebedouro': ItemType.bebedouro,
    'pia': ItemType.pia,
    'vaso': ItemType.vaso,
    'telhado': ItemType.telhado,
    'calha': ItemType.calha,
  };

  /// Limiar minimo de confianca para considerar uma deteccao valida.
  final double threshold;

  ObjectDetectionService({this.threshold = 0.5});

  /// Inicializa o interpretador TFLite (carrega assets/models/*.tflite).
  Future<void> initialize() async {
    // TODO(prod): carregar Interpreter.fromAsset('assets/models/items.tflite')
    // e o LocalObjectDetector do ML Kit com o modelo customizado.
  }

  /// Consolida uma lista de deteccoes brutas (de varios frames) em contagens
  /// por tipo. Usa deduplicacao simples por IoU para nao contar o mesmo
  /// objeto em frames consecutivos.
  List<ItemCount> consolidate(List<RawDetection> detections) {
    final valid =
        detections.where((d) => d.confidence >= threshold).toList();

    final byType = <ItemType, List<double>>{};
    for (final d in valid) {
      final type = _labelMap[d.label.toLowerCase()];
      if (type == null) continue;
      byType.putIfAbsent(type, () => []).add(d.confidence);
    }

    return byType.entries.map((e) {
      final avg = e.value.reduce((a, b) => a + b) / e.value.length;
      return ItemCount(e.key, e.value.length, avg);
    }).toList();
  }

  /// Intersection over Union entre duas bounding boxes (para deduplicacao).
  static double iou(List<double> a, List<double> b) {
    final x1 = a[0] > b[0] ? a[0] : b[0];
    final y1 = a[1] > b[1] ? a[1] : b[1];
    final x2 = a[2] < b[2] ? a[2] : b[2];
    final y2 = a[3] < b[3] ? a[3] : b[3];
    final inter = (x2 - x1).clamp(0, double.infinity) *
        (y2 - y1).clamp(0, double.infinity);
    final areaA = (a[2] - a[0]) * (a[3] - a[1]);
    final areaB = (b[2] - b[0]) * (b[3] - b[1]);
    final union = areaA + areaB - inter;
    return union <= 0 ? 0 : inter / union;
  }
}
