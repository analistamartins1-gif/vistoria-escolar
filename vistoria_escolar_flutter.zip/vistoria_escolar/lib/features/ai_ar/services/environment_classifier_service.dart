import '../../../core/constants/enums.dart';

/// Identifica automaticamente o tipo de ambiente a partir da imagem
/// (passo 1 do "Modo IA" recomendado): sala, banheiro, cozinha, etc.
///
/// Usa image labeling (ML Kit) + classificador TFLite. A sugestao e sempre
/// confirmada pelo usuario antes de criar o ambiente.
class EnvironmentClassifierService {
  static const Map<String, EnvironmentType> _labelMap = {
    'sala_de_aula': EnvironmentType.salaDeAula,
    'banheiro': EnvironmentType.banheiro,
    'cozinha': EnvironmentType.cozinha,
    'biblioteca': EnvironmentType.biblioteca,
    'laboratorio': EnvironmentType.laboratorio,
    'corredor': EnvironmentType.corredor,
    'refeitorio': EnvironmentType.refeitorio,
    'quadra': EnvironmentType.quadra,
    'patio': EnvironmentType.patio,
    'secretaria': EnvironmentType.secretaria,
    'diretoria': EnvironmentType.diretoria,
  };

  Future<void> initialize() async {}

  /// Retorna o tipo mais provavel e a confianca (0..1).
  ({EnvironmentType type, double confidence}) classify(
    Map<String, double> labels,
  ) {
    var best = EnvironmentType.outros;
    var bestScore = 0.0;
    labels.forEach((label, score) {
      final type = _labelMap[label.toLowerCase()];
      if (type != null && score > bestScore) {
        best = type;
        bestScore = score;
      }
    });
    return (type: best, confidence: bestScore);
  }
}
