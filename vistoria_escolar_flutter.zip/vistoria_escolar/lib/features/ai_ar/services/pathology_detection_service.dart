import '../../../core/constants/enums.dart';

/// Sugestao de patologia produzida pela IA (requisito 11).
class PathologySuggestion {
  const PathologySuggestion(this.type, this.confidence, this.severityHint);
  final PathologyType type;
  final double confidence; // 0..1
  final int severityHint; // 1..5

  ConfidenceLevel get level => confidence >= 0.75
      ? ConfidenceLevel.alta
      : confidence >= 0.5
          ? ConfidenceLevel.media
          : ConfidenceLevel.baixa;
}

/// Servico de deteccao de manifestacoes patologicas em imagens
/// (fissuras, infiltracoes, mofo, eflorescencia, etc.) via classificador
/// TFLite treinado + heuristicas de visao computacional (OpenCV).
///
/// A saida sao SUGESTOES: o engenheiro/arquiteto confirma ou descarta.
class PathologyDetectionService {
  static const Map<String, PathologyType> _labelMap = {
    'trinca': PathologyType.trinca,
    'fissura': PathologyType.fissura,
    'infiltracao': PathologyType.infiltracao,
    'mofo': PathologyType.mofo,
    'bolor': PathologyType.bolor,
    'eflorescencia': PathologyType.eflorescencia,
    'corrosao': PathologyType.corrosao,
    'pintura_descascando': PathologyType.pinturaDescascando,
    'ceramica_solta': PathologyType.ceramicaSolta,
    'piso_quebrado': PathologyType.pisoQuebrado,
    'esquadria_danificada': PathologyType.esquadriaDanificada,
    'cobertura_comprometida': PathologyType.coberturaComprometida,
  };

  final double threshold;
  PathologyDetectionService({this.threshold = 0.45});

  Future<void> initialize() async {
    // TODO(prod): carregar assets/models/pathologies.tflite
  }

  /// Analisa a saida do classificador (label->score) e retorna sugestoes
  /// ordenadas por confianca. [imageBytes] seria usado em producao.
  List<PathologySuggestion> analyze(Map<String, double> classifierOutput) {
    final out = <PathologySuggestion>[];
    classifierOutput.forEach((label, score) {
      final type = _labelMap[label.toLowerCase()];
      if (type == null || score < threshold) return;
      out.add(PathologySuggestion(type, score, _severityFor(type, score)));
    });
    out.sort((a, b) => b.confidence.compareTo(a.confidence));
    return out;
  }

  /// Gravidade heuristica: patologias estruturais recebem peso maior.
  int _severityFor(PathologyType type, double score) {
    const structural = {
      PathologyType.trinca,
      PathologyType.corrosao,
      PathologyType.coberturaComprometida,
    };
    final base = structural.contains(type) ? 4 : 2;
    return (base + (score >= 0.8 ? 1 : 0)).clamp(1, 5);
  }
}
