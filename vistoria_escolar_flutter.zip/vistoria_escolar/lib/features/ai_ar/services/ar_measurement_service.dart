import 'package:vector_math/vector_math_64.dart';

import '../../../core/constants/enums.dart';
import '../../../core/utils/geometry_utils.dart';
import '../../survey/domain/entities/measurement.dart';

/// Resultado de disponibilidade do AR no dispositivo.
enum ArAvailability { supported, unsupported, needsUpdate, unknown }

/// Servico de medicao por Realidade Aumentada (requisitos 3 e 4).
///
/// Abstrai o plugin de AR (ARCore no Android / ARKit no iOS). A regra de
/// negocio importante, conforme recomendacao tecnica, e:
///   * Toda medida por AR e ESTIMATIVA.
///   * O servico SEMPRE retorna um [ConfidenceLevel] junto com a medida.
///   * A UI deve exibir a confianca e permitir edicao/validacao manual antes
///     de usar em orcamento ou contratacao publica.
///
/// Em producao, os metodos de captura de pontos sao alimentados pelos
/// callbacks de "hit test" do plugin ar_flutter_plugin. Aqui a logica de
/// calculo e isolada para ser testavel.
class ArMeasurementService {
  /// Pontos capturados no espaco 3D (em metros) durante a sessao.
  final List<Vector3> _points = [];

  /// Verifica se o dispositivo suporta AR. Em producao, consulta o plugin.
  Future<ArAvailability> checkAvailability() async {
    // TODO(prod): integrar com ArCoreController / ARKit availability check.
    return ArAvailability.supported;
  }

  /// Registra um ponto captado por hit-test (ex.: canto inferior/superior).
  void addPoint(Vector3 point) => _points.add(point);

  void reset() => _points.clear();

  /// Mede uma PAREDE a partir de dois cantos: inferior e superior de um lado
  /// e a largura ate o canto oposto. Fluxo do requisito 4:
  ///   usuario aponta canto inferior -> canto superior (altura)
  ///   depois desliza ate o outro extremo (largura).
  ///
  /// [bottom], [top] definem a altura; [bottomOpposite] a largura.
  /// [trackingQuality] (0..1) vem do plugin (estado do tracking/iluminacao).
  Measurement measureWall({
    required Vector3 bottom,
    required Vector3 top,
    required Vector3 bottomOpposite,
    required double trackingQuality,
  }) {
    final height = GeometryUtils.distance3d(bottom, top);
    final width = GeometryUtils.distance3d(bottom, bottomOpposite);

    return Measurement(
      widthM: _round2(width),
      heightM: _round2(height),
      confidence: _confidenceFrom(trackingQuality, height, width),
      confidenceScore: trackingQuality,
      source: 'ar',
    );
  }

  /// Calcula a area de piso a partir dos cantos marcados no chao
  /// (poligono). Retorna area em m² (metodo do shoelace projetado no plano).
  double measureFloorArea(List<Vector3> floorCorners) {
    final planar = floorCorners.map((v) => Vector2(v.x, v.z)).toList();
    return GeometryUtils.polygonArea(planar);
  }

  /// Deriva o nivel de confianca a partir da qualidade do tracking e de
  /// verificacoes de sanidade (medidas plausiveis para ambientes escolares).
  ConfidenceLevel _confidenceFrom(
    double tracking,
    double height,
    double width,
  ) {
    // Sanidade: altura tipica de 2.4 a 4.0 m; largura 0.5 a 15 m.
    final plausible =
        height >= 1.8 && height <= 5.0 && width >= 0.3 && width <= 20.0;
    if (!plausible) return ConfidenceLevel.baixa;
    if (tracking >= 0.75) return ConfidenceLevel.alta;
    if (tracking >= 0.5) return ConfidenceLevel.media;
    return ConfidenceLevel.baixa;
  }

  static double _round2(double v) => (v * 100).round() / 100;
}
