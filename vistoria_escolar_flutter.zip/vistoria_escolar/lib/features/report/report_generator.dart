import 'dart:io';
import 'dart:typed_data';

import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';

import '../survey/domain/entities/school.dart';
import '../survey/domain/entities/environment.dart';
import '../survey/domain/entities/quantities.dart';
import '../survey/domain/entities/pathology.dart';
import '../survey/domain/entities/checklist_item.dart';
import '../survey/domain/usecases/suggest_services.dart';
import '../../core/constants/enums.dart';

/// Dados agregados de um ambiente para compor o relatorio.
class EnvironmentReportData {
  const EnvironmentReportData({
    required this.environment,
    required this.quantities,
    required this.pathologies,
    required this.checklist,
    required this.photoPaths,
    required this.suggestions,
  });

  final Environment environment;
  final Quantities quantities;
  final List<Pathology> pathologies;
  final List<ChecklistItem> checklist;
  final List<String> photoPaths;
  final List<ServiceSuggestion> suggestions;
}

/// Gera o relatorio tecnico de vistoria em PDF (requisito 17).
///
/// Inclui capa, dados da escola, e por ambiente: quantitativos, checklist,
/// patologias, sugestoes de servico e fotos. As exportacoes DOCX/XLSX/CSV
/// (requisito 22) seguem a mesma estrutura usando os pacotes `excel`/`csv`.
class ReportGenerator {
  final _dateFmt = DateFormat('dd/MM/yyyy HH:mm');

  Future<File> generatePdf({
    required School school,
    required List<EnvironmentReportData> environments,
  }) async {
    final doc = pw.Document();

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        build: (context) => [
          _cover(school),
          pw.SizedBox(height: 12),
          ...environments.expand(_environmentSection),
        ],
        footer: (context) => pw.Align(
          alignment: pw.Alignment.centerRight,
          child: pw.Text(
            'Pagina ${context.pageNumber}/${context.pagesCount}',
            style: const pw.TextStyle(fontSize: 9),
          ),
        ),
      ),
    );

    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/relatorio_${school.processNumber}.pdf');
    await file.writeAsBytes(await doc.save());
    return file;
  }

  pw.Widget _cover(School school) => pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text('RELATORIO TECNICO DE VISTORIA',
              style:
                  pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
          pw.Divider(),
          _kv('Escola', school.name),
          _kv('Endereco', school.address),
          _kv('Coordenadas',
              '${school.latitude}, ${school.longitude}'),
          _kv('Diretor', school.director),
          _kv('Telefone', school.phone),
          _kv('Responsavel', school.inspector),
          _kv('Data', _dateFmt.format(school.visitDate)),
          _kv('Processo', school.processNumber),
          _kv('Tipo', school.surveyType.label),
        ],
      );

  Iterable<pw.Widget> _environmentSection(EnvironmentReportData d) sync* {
    yield pw.SizedBox(height: 16);
    yield pw.Header(level: 1, text: 'Ambiente: ${d.environment.code}');

    // Quantitativos.
    yield pw.Text('Quantitativos',
        style: pw.TextStyle(fontWeight: pw.FontWeight.bold));
    yield pw.TableHelper.fromTextArray(
      headers: const ['Item', 'Valor'],
      data: d.quantities
          .toReportRows()
          .entries
          .map((e) => [e.key, e.value.toString()])
          .toList(),
    );

    // Checklist.
    if (d.checklist.isNotEmpty) {
      yield pw.SizedBox(height: 8);
      yield pw.Text('Checklist',
          style: pw.TextStyle(fontWeight: pw.FontWeight.bold));
      yield pw.TableHelper.fromTextArray(
        headers: const ['Elemento', 'Estado', 'Obs.'],
        data: d.checklist
            .map((c) => [c.subject, c.state.name, c.note])
            .toList(),
      );
    }

    // Patologias.
    if (d.pathologies.isNotEmpty) {
      yield pw.SizedBox(height: 8);
      yield pw.Text('Patologias',
          style: pw.TextStyle(fontWeight: pw.FontWeight.bold));
      yield pw.TableHelper.fromTextArray(
        headers: const ['Tipo', 'Gravidade', 'Confianca'],
        data: d.pathologies
            .map((p) =>
                [p.type.name, '${p.severity}/5', p.confidence.label])
            .toList(),
      );
    }

    // Sugestoes de servico (requisito 16).
    if (d.suggestions.isNotEmpty) {
      yield pw.SizedBox(height: 8);
      yield pw.Text('Servicos recomendados',
          style: pw.TextStyle(fontWeight: pw.FontWeight.bold));
      yield pw.TableHelper.fromTextArray(
        headers: const ['Servico', 'Prioridade', 'Risco'],
        data: d.suggestions
            .map((s) => [s.service, s.priority.name, s.risk])
            .toList(),
      );
    }

    // Fotos.
    for (final path in d.photoPaths) {
      final file = File(path);
      if (!file.existsSync()) continue;
      yield pw.SizedBox(height: 8);
      yield pw.Image(
        pw.MemoryImage(file.readAsBytesSync() as Uint8List),
        height: 180,
        fit: pw.BoxFit.contain,
      );
    }
  }

  pw.Widget _kv(String k, String v) => pw.Padding(
        padding: const pw.EdgeInsets.symmetric(vertical: 2),
        child: pw.Row(children: [
          pw.SizedBox(
              width: 110,
              child: pw.Text('$k:',
                  style: pw.TextStyle(fontWeight: pw.FontWeight.bold))),
          pw.Expanded(child: pw.Text(v)),
        ]),
      );
}
