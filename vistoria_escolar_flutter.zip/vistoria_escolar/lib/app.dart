import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/theme/app_theme.dart';
import 'presentation/dashboard/dashboard_screen.dart';

/// Provider que controla o modo de tema (claro/escuro/sistema).
///
/// Mantido no nivel do app para que o botao de alternancia (menu lateral)
/// possa altera-lo de qualquer tela.
final themeModeProvider = StateProvider<ThemeMode>((ref) => ThemeMode.system);

/// Widget raiz do aplicativo.
///
/// Configura tema claro/escuro, localizacao (pt-BR) e a tela inicial
/// (Dashboard, estilo Google Maps com menu lateral).
class VistoriaApp extends ConsumerWidget {
  const VistoriaApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeModeProvider);

    return MaterialApp(
      title: 'Vistoria Escolar',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: themeMode,
      home: const DashboardScreen(),
    );
  }
}
