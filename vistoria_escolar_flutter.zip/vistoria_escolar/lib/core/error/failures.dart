import 'package:equatable/equatable.dart';

/// Representa uma falha tratada da aplicacao (camada de dominio).
///
/// Uso de Failure (em vez de exceptions cruas) mantem a camada de
/// apresentacao desacoplada dos detalhes de infraestrutura (SOLID/DIP).
sealed class Failure extends Equatable {
  const Failure(this.message);
  final String message;

  @override
  List<Object?> get props => [message];
}

/// Falha ao acessar o banco de dados local (SQLite).
class DatabaseFailure extends Failure {
  const DatabaseFailure(super.message);
}

/// Falha de sincronizacao com a nuvem (Firebase).
class SyncFailure extends Failure {
  const SyncFailure(super.message);
}

/// Falha em servicos de IA/AR (medicao, deteccao, classificacao).
class AiFailure extends Failure {
  const AiFailure(super.message);
}

/// Dispositivo nao suporta AR (ARCore/ARKit ausente).
class ArUnsupportedFailure extends Failure {
  const ArUnsupportedFailure()
      : super(
          'Este dispositivo nao suporta AR. Use a medicao manual (trena).',
        );
}
