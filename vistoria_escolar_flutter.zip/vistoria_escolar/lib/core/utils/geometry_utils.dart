import 'dart:math' as math;
import 'package:vector_math/vector_math_64.dart';

/// Utilitarios geometricos usados na medicao por AR e no calculo de
/// quantitativos. Todo o codigo aqui e testavel de forma isolada (Dart puro).
class GeometryUtils {
  GeometryUtils._();

  /// Distancia euclidiana (em metros) entre dois pontos 3D captados pelo AR.
  static double distance3d(Vector3 a, Vector3 b) => (a - b).length;

  /// Area de um retangulo dado largura e altura (m²), arredondada a 2 casas.
  static double rectangleArea(double width, double height) =>
      _round2(width * height);

  /// Perimetro de um retangulo (m).
  static double rectanglePerimeter(double width, double height) =>
      _round2(2 * (width + height));

  /// Area de um poligono no plano (metodo do shoelace / Gauss).
  ///
  /// Usado quando o ambiente nao e retangular e o usuario marca varios
  /// cantos no chao com o AR.
  static double polygonArea(List<Vector2> points) {
    if (points.length < 3) return 0;
    var sum = 0.0;
    for (var i = 0; i < points.length; i++) {
      final p1 = points[i];
      final p2 = points[(i + 1) % points.length];
      sum += (p1.x * p2.y) - (p2.x * p1.y);
    }
    return _round2(sum.abs() / 2);
  }

  /// Angulo (graus) entre tres pontos (b = vertice). Util para checar se
  /// um canto e proximo de 90 graus e validar a medicao.
  static double angleDegrees(Vector3 a, Vector3 b, Vector3 c) {
    final v1 = a - b;
    final v2 = c - b;
    final cos = v1.dot(v2) / (v1.length * v2.length);
    return _round2(math.acos(cos.clamp(-1.0, 1.0)) * 180 / math.pi);
  }

  static double _round2(double v) => (v * 100).round() / 100;
}
