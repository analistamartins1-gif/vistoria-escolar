/// Enumeracoes de dominio do levantamento tecnico.

/// Tipo da vistoria (requisito 1).
enum SurveyType { reforma, ampliacao, manutencao, novaConstrucao }

extension SurveyTypeX on SurveyType {
  String get label => switch (this) {
        SurveyType.reforma => 'Reforma',
        SurveyType.ampliacao => 'Ampliacao',
        SurveyType.manutencao => 'Manutencao',
        SurveyType.novaConstrucao => 'Nova Construcao',
      };
}

/// Tipos de ambiente (requisito 2).
enum EnvironmentType {
  salaDeAula,
  secretaria,
  diretoria,
  banheiro,
  biblioteca,
  laboratorio,
  corredor,
  cozinha,
  refeitorio,
  quadra,
  patio,
  deposito,
  almoxarifado,
  salaDosProfessores,
  outros,
}

extension EnvironmentTypeX on EnvironmentType {
  String get label => switch (this) {
        EnvironmentType.salaDeAula => 'Sala de Aula',
        EnvironmentType.secretaria => 'Secretaria',
        EnvironmentType.diretoria => 'Diretoria',
        EnvironmentType.banheiro => 'Banheiro',
        EnvironmentType.biblioteca => 'Biblioteca',
        EnvironmentType.laboratorio => 'Laboratorio',
        EnvironmentType.corredor => 'Corredor',
        EnvironmentType.cozinha => 'Cozinha',
        EnvironmentType.refeitorio => 'Refeitorio',
        EnvironmentType.quadra => 'Quadra',
        EnvironmentType.patio => 'Patio',
        EnvironmentType.deposito => 'Deposito',
        EnvironmentType.almoxarifado => 'Almoxarifado',
        EnvironmentType.salaDosProfessores => 'Sala dos Professores',
        EnvironmentType.outros => 'Outros',
      };

  /// Prefixo sugerido para o codigo do ambiente (ex.: SALA 01).
  String get codePrefix => switch (this) {
        EnvironmentType.salaDeAula => 'SALA',
        EnvironmentType.banheiro => 'BANHEIRO',
        EnvironmentType.laboratorio => 'LAB',
        EnvironmentType.corredor => 'CORREDOR',
        _ => label.toUpperCase(),
      };
}

/// Categorias de itens detectaveis pela IA (requisito 5).
enum ItemType {
  porta,
  janela,
  quadro,
  pilar,
  viga,
  luminaria,
  ventilador,
  tomada,
  interruptor,
  extintor,
  bebedouro,
  pia,
  vaso,
  telhado,
  calha,
}

/// Tipos de patologia sugeridos pela IA (requisito 11).
enum PathologyType {
  trinca,
  fissura,
  infiltracao,
  mofo,
  bolor,
  eflorescencia,
  corrosao,
  pinturaDescascando,
  ceramicaSolta,
  pisoQuebrado,
  esquadriaDanificada,
  coberturaComprometida,
}

/// Estado de conservacao usado no checklist (requisito 12).
enum ConservationState { bom, regular, ruim }

/// Nivel de confianca de uma medicao/deteccao por IA (recomendacao do usuario).
enum ConfidenceLevel { alta, media, baixa, manual }

extension ConfidenceLevelX on ConfidenceLevel {
  String get label => switch (this) {
        ConfidenceLevel.alta => 'Alta',
        ConfidenceLevel.media => 'Media',
        ConfidenceLevel.baixa => 'Baixa (confira com trena)',
        ConfidenceLevel.manual => 'Manual (validado)',
      };
}

/// Perfis de acesso (requisito 23).
enum UserRole { administrador, engenheiro, arquiteto, fiscal, visualizador }
