/// Constantes globais do aplicativo.
class AppConstants {
  AppConstants._();

  static const String appName = 'Vistoria Escolar';
  static const String dbName = 'vistoria_escolar.db';
  static const int dbVersion = 1;

  /// Limite de duracao de video (segundos) conforme requisito 9.
  static const int maxVideoSeconds = 60;

  /// Nome das colecoes no Firestore (sincronizacao - requisito 21).
  static const String colSchools = 'schools';
  static const String colEnvironments = 'environments';
  static const String colReports = 'reports';
}
