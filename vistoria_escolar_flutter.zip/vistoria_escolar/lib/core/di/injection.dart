import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:get_it/get_it.dart';

import '../../features/survey/data/datasources/app_database.dart';
import '../../features/survey/data/repositories/survey_repository_impl.dart';
import '../../features/survey/domain/repositories/survey_repository.dart';
import '../../features/ai_ar/domain/quantification_engine.dart';
import '../../features/ai_ar/services/ar_measurement_service.dart';
import '../../features/ai_ar/services/object_detection_service.dart';
import '../../features/ai_ar/services/pathology_detection_service.dart';
import '../../features/ai_ar/services/environment_classifier_service.dart';
import '../../features/ai_ar/services/speech_to_text_service.dart';
import '../sync/sync_service.dart';

/// Service locator global (GetIt) para dependencias sem estado reativo.
final GetIt sl = GetIt.instance;

/// Inicializacao da infraestrutura, chamada em main() antes do runApp.
///
/// Registra o banco local e servicos. Firebase e inicializado aqui em
/// producao; envolvido em try/catch para nao quebrar o modo offline.
Future<void> bootstrap() async {
  // Banco de dados local (abre lazy no primeiro acesso).
  sl.registerSingleton<AppDatabase>(AppDatabase.instance);

  // Repositorio (offline-first).
  sl.registerSingleton<SurveyRepository>(
    SurveyRepositoryImpl(sl<AppDatabase>()),
  );

  // Motor de quantificacao (Dart puro, sem dependencias externas).
  sl.registerSingleton<QuantificationEngine>(const QuantificationEngine());

  // Servicos de IA/AR.
  sl.registerLazySingleton<ArMeasurementService>(ArMeasurementService.new);
  sl.registerLazySingleton<ObjectDetectionService>(ObjectDetectionService.new);
  sl.registerLazySingleton<PathologyDetectionService>(
      PathologyDetectionService.new);
  sl.registerLazySingleton<EnvironmentClassifierService>(
      EnvironmentClassifierService.new);
  sl.registerLazySingleton<SpeechToTextService>(SpeechToTextService.new);

  // Sincronizacao.
  sl.registerLazySingleton<SyncService>(
    () => SyncService(sl<SurveyRepository>()),
  );

  // OBS.: em producao, inicialize o Firebase aqui:
  //   try { await Firebase.initializeApp(...); } catch (_) { /* offline */ }
}

// -------------------- Providers Riverpod (ponte com GetIt) --------------------

/// Expoe o repositorio ao Riverpod, mantendo a UI desacoplada do GetIt.
final surveyRepositoryProvider =
    Provider<SurveyRepository>((ref) => sl<SurveyRepository>());

final quantificationEngineProvider =
    Provider<QuantificationEngine>((ref) => sl<QuantificationEngine>());

final arMeasurementServiceProvider =
    Provider<ArMeasurementService>((ref) => sl<ArMeasurementService>());

final objectDetectionServiceProvider =
    Provider<ObjectDetectionService>((ref) => sl<ObjectDetectionService>());

final pathologyDetectionServiceProvider =
    Provider<PathologyDetectionService>(
        (ref) => sl<PathologyDetectionService>());

final environmentClassifierProvider =
    Provider<EnvironmentClassifierService>(
        (ref) => sl<EnvironmentClassifierService>());

final speechToTextServiceProvider =
    Provider<SpeechToTextService>((ref) => sl<SpeechToTextService>());

final syncServiceProvider =
    Provider<SyncService>((ref) => sl<SyncService>());
