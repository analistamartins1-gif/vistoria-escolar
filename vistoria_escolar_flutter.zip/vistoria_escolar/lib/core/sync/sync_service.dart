import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';

import '../../features/survey/domain/repositories/survey_repository.dart';

/// Servico de sincronizacao offline-first (requisitos 20 e 21).
///
/// Estrategia:
///  * O app SEMPRE grava primeiro no SQLite local (funciona sem internet).
///  * Este servico observa a conectividade; quando houver rede, envia os
///    registros pendentes (synced = 0) para o Firebase e marca como enviados.
///
/// A integracao concreta com Firestore/Storage e indicada nos TODO(prod).
class SyncService {
  SyncService(this._repository);

  final SurveyRepository _repository;
  StreamSubscription<List<ConnectivityResult>>? _sub;
  bool _syncing = false;

  /// Comeca a observar a conectividade e sincroniza quando online.
  void start() {
    _sub = Connectivity().onConnectivityChanged.listen((results) {
      final online = results.any((r) => r != ConnectivityResult.none);
      if (online) unawaited(syncNow());
    });
  }

  Future<void> stop() async => _sub?.cancel();

  /// Envia todos os registros pendentes. Idempotente e reentrante-seguro.
  Future<void> syncNow() async {
    if (_syncing) return;
    _syncing = true;
    try {
      final pending = await _repository.getUnsyncedSchools();
      for (final school in pending) {
        // TODO(prod): FirebaseFirestore.instance
        //   .collection('schools').doc(school.id).set(schoolToJson(school));
        //   + upload de fotos/videos/audios para o Firebase Storage.
        await _repository.markSchoolSynced(school.id);
      }
    } finally {
      _syncing = false;
    }
  }
}
