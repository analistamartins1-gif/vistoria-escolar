import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../../core/constants/enums.dart';
import '../../core/di/injection.dart';
import '../../features/survey/domain/entities/school.dart';
import '../../features/survey/domain/entities/environment.dart';
import '../../features/ai_ar/presentation/ar_scan_screen.dart';
import '../../features/ai_ar/presentation/ai_scan_controller.dart';
import 'environment_detail_screen.dart';
import '../providers.dart';

/// Lista de ambientes da escola (requisito 2). Botao "Modo IA" inicia a
/// varredura por camera/AR.
class EnvironmentListScreen extends ConsumerWidget {
  const EnvironmentListScreen({required this.school, super.key});
  final School school;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final envs = ref.watch(environmentsProvider(school.id));

    return Scaffold(
      appBar: AppBar(title: Text(school.name)),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.view_in_ar),
        label: const Text('Modo IA'),
        onPressed: () => _startAiScan(context, ref),
      ),
      body: envs.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Erro: $e')),
        data: (list) => Column(
          children: [
            Expanded(
              child: list.isEmpty
                  ? const Center(child: Text('Nenhum ambiente. Use o Modo IA.'))
                  : ListView.builder(
                      itemCount: list.length,
                      itemBuilder: (_, i) {
                        final e = list[i];
                        return ListTile(
                          leading: const Icon(Icons.meeting_room),
                          title: Text(e.code),
                          subtitle: Text(
                              '${e.type.label} - ${e.walls.length} paredes'),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                                  EnvironmentDetailScreen(environment: e),
                            ),
                          ),
                        );
                      },
                    ),
            ),
            _AddManualButton(school: school),
          ],
        ),
      ),
    );
  }

  /// Inicia a varredura por IA e, ao retornar, persiste o ambiente medido.
  Future<void> _startAiScan(BuildContext context, WidgetRef ref) async {
    final result = await Navigator.push<AiScanState>(
      context,
      MaterialPageRoute(
        builder: (_) => ArScanScreen(schoolId: school.id),
      ),
    );
    if (result == null) return;

    final repo = ref.read(surveyRepositoryProvider);
    final existing = await repo.getEnvironments(school.id);
    final type = result.suggestedType ?? EnvironmentType.outros;
    final code = '${type.codePrefix} ${existing.length + 1}';

    final env = Environment(
      id: const Uuid().v4(),
      schoolId: school.id,
      code: code,
      type: type,
      walls: result.walls,
      floorAreaM2: 0,
    );
    await repo.saveEnvironment(env);
    for (final w in result.walls) {
      await repo.saveWall(w);
    }
    ref.invalidate(environmentsProvider(school.id));
    ref.invalidate(dashboardMetricsProvider);
  }
}

class _AddManualButton extends ConsumerWidget {
  const _AddManualButton({required this.school});
  final School school;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: OutlinedButton.icon(
        icon: const Icon(Icons.edit),
        label: const Text('Adicionar ambiente manualmente'),
        onPressed: () async {
          final repo = ref.read(surveyRepositoryProvider);
          final existing = await repo.getEnvironments(school.id);
          await repo.saveEnvironment(
            Environment(
              id: const Uuid().v4(),
              schoolId: school.id,
              code: 'SALA ${existing.length + 1}',
              type: EnvironmentType.salaDeAula,
              walls: const [],
            ),
          );
          ref.invalidate(environmentsProvider(school.id));
        },
      ),
    );
  }
}
