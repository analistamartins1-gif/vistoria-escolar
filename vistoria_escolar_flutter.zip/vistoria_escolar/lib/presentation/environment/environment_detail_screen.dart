import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';

import '../../core/constants/enums.dart';
import '../../core/di/injection.dart';
import '../../features/survey/domain/entities/environment.dart';
import '../../features/survey/domain/entities/photo.dart';
import '../providers.dart';

/// Detalhe de um ambiente (requisito 2 e 8).
///
/// Permite capturar fotos com a camera do aparelho e vincula-las ao ambiente.
/// A foto e copiada para o diretorio do app (persistencia offline) e um
/// registro [Photo] e salvo no banco local.
class EnvironmentDetailScreen extends ConsumerWidget {
  const EnvironmentDetailScreen({required this.environment, super.key});

  final Environment environment;

  Future<void> _capturePhoto(BuildContext context, WidgetRef ref) async {
    final picker = ImagePicker();
    // Abre o app de camera do sistema (nao exige permissao CAMERA no manifest).
    final shot = await picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 80,
      maxWidth: 1920,
    );
    if (shot == null) return;

    // Copia o arquivo para o diretorio persistente do app.
    final dir = await getApplicationDocumentsDirectory();
    final id = const Uuid().v4();
    final dest = p.join(dir.path, 'photo_$id.jpg');
    await File(shot.path).copy(dest);

    final photo = Photo(
      id: id,
      environmentId: environment.id,
      localPath: dest,
      category: PhotoCategory.geral,
      takenAt: DateTime.now(),
    );
    await ref.read(surveyRepositoryProvider).savePhoto(photo);
    ref.invalidate(photosProvider(environment.id));
    ref.invalidate(dashboardMetricsProvider);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final photos = ref.watch(photosProvider(environment.id));

    return Scaffold(
      appBar: AppBar(title: Text(environment.code)),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.photo_camera),
        label: const Text('Tirar foto'),
        onPressed: () => _capturePhoto(context, ref),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              '${environment.type.label}  -  ${environment.walls.length} '
              'parede(s)',
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: photos.when(
              loading: () =>
                  const Center(child: CircularProgressIndicator()),
              error: (e, _) => Center(child: Text('Erro: $e')),
              data: (list) => list.isEmpty
                  ? const Center(
                      child: Text('Nenhuma foto. Toque em "Tirar foto".'),
                    )
                  : GridView.builder(
                      padding: const EdgeInsets.all(12),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        mainAxisSpacing: 8,
                        crossAxisSpacing: 8,
                      ),
                      itemCount: list.length,
                      itemBuilder: (_, i) => ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.file(
                          File(list[i].localPath),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}
