import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/di/injection.dart';
import '../features/survey/domain/entities/school.dart';
import '../features/survey/domain/entities/environment.dart';

/// Lista todas as escolas cadastradas (offline, do SQLite).
final schoolsProvider = FutureProvider<List<School>>((ref) async {
  final repo = ref.watch(surveyRepositoryProvider);
  return repo.getSchools();
});

/// Ambientes de uma escola.
final environmentsProvider =
    FutureProvider.family<List<Environment>, String>((ref, schoolId) async {
  final repo = ref.watch(surveyRepositoryProvider);
  return repo.getEnvironments(schoolId);
});

/// Metricas agregadas para o Dashboard (requisito 18).
class DashboardMetrics {
  const DashboardMetrics({
    required this.schools,
    required this.environments,
    required this.totalFloorAreaM2,
    required this.totalPaintAreaM2,
  });
  final int schools;
  final int environments;
  final double totalFloorAreaM2;
  final double totalPaintAreaM2;
}

final dashboardMetricsProvider =
    FutureProvider<DashboardMetrics>((ref) async {
  final repo = ref.watch(surveyRepositoryProvider);
  final schools = await repo.getSchools();
  var envCount = 0;
  var floor = 0.0;
  var paint = 0.0;
  for (final s in schools) {
    final envs = await repo.getEnvironments(s.id);
    envCount += envs.length;
    for (final e in envs) {
      floor += e.floorAreaM2;
      for (final w in e.walls) {
        paint += w.netPaintAreaM2;
      }
    }
  }
  return DashboardMetrics(
    schools: schools.length,
    environments: envCount,
    totalFloorAreaM2: (floor * 100).round() / 100,
    totalPaintAreaM2: (paint * 100).round() / 100,
  );
});
