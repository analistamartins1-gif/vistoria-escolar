import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/constants/enums.dart';

import '../providers.dart';
import '../environment/environment_list_screen.dart';
import 'school_form_screen.dart';

/// Lista de escolas cadastradas; toque abre os ambientes.
class SchoolListScreen extends ConsumerWidget {
  const SchoolListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final schools = ref.watch(schoolsProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Escolas')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const SchoolFormScreen()),
        ),
        child: const Icon(Icons.add),
      ),
      body: schools.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Erro: $e')),
        data: (list) => list.isEmpty
            ? const Center(child: Text('Nenhuma escola cadastrada.'))
            : ListView.separated(
                itemCount: list.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (_, i) {
                  final s = list[i];
                  return ListTile(
                    leading: CircleAvatar(
                      child: Icon(
                        s.synced ? Icons.cloud_done : Icons.cloud_off,
                      ),
                    ),
                    title: Text(s.name),
                    subtitle: Text('${s.surveyType.label} - ${s.processNumber}'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => EnvironmentListScreen(school: s),
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
