import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';

import '../../core/constants/enums.dart';
import '../../core/di/injection.dart';
import '../../features/survey/domain/entities/school.dart';
import '../providers.dart';

/// Formulario de cadastro da escola antes da vistoria (requisito 1).
class SchoolFormScreen extends ConsumerStatefulWidget {
  const SchoolFormScreen({super.key});

  @override
  ConsumerState<SchoolFormScreen> createState() => _SchoolFormScreenState();
}

class _SchoolFormScreenState extends ConsumerState<SchoolFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _address = TextEditingController();
  final _director = TextEditingController();
  final _phone = TextEditingController();
  final _inspector = TextEditingController();
  final _process = TextEditingController();
  SurveyType _type = SurveyType.reforma;
  double? _lat;
  double? _lng;

  @override
  void dispose() {
    for (final c in [
      _name,
      _address,
      _director,
      _phone,
      _inspector,
      _process,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  /// Captura das coordenadas GPS - FASE 2.
  ///
  /// A captura automatica usa o pacote `geolocator` (descomente no pubspec
  /// e implemente aqui). Por enquanto, as coordenadas podem ser informadas
  /// manualmente ou ficam zeradas.
  Future<void> _captureGps() async {
    // TODO(prod): Geolocator.requestPermission() + getCurrentPosition()
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Captura automatica de GPS: disponivel na Fase 2.'),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final school = School(
      id: const Uuid().v4(),
      name: _name.text,
      address: _address.text,
      latitude: _lat ?? 0,
      longitude: _lng ?? 0,
      director: _director.text,
      phone: _phone.text,
      inspector: _inspector.text,
      visitDate: DateTime.now(),
      processNumber: _process.text,
      surveyType: _type,
    );
    await ref.read(surveyRepositoryProvider).saveSchool(school);
    ref.invalidate(schoolsProvider);
    ref.invalidate(dashboardMetricsProvider);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Nova escola')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _field(_name, 'Nome da escola', required: true),
            _field(_address, 'Endereco'),
            Row(children: [
              Expanded(
                child: Text(_lat == null
                    ? 'GPS nao capturado'
                    : 'GPS: ${_lat!.toStringAsFixed(5)}, '
                        '${_lng!.toStringAsFixed(5)}'),
              ),
              TextButton.icon(
                icon: const Icon(Icons.my_location),
                label: const Text('Capturar'),
                onPressed: _captureGps,
              ),
            ]),
            _field(_director, 'Diretor'),
            _field(_phone, 'Telefone'),
            _field(_inspector, 'Responsavel pela visita'),
            _field(_process, 'Numero do processo', required: true),
            const SizedBox(height: 8),
            DropdownButtonFormField<SurveyType>(
              value: _type,
              decoration: const InputDecoration(labelText: 'Tipo da vistoria'),
              items: SurveyType.values
                  .map((t) =>
                      DropdownMenuItem(value: t, child: Text(t.label)))
                  .toList(),
              onChanged: (v) => setState(() => _type = v ?? _type),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              icon: const Icon(Icons.save),
              label: const Text('Salvar escola'),
              onPressed: _save,
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController c, String label,
          {bool required = false}) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextFormField(
          controller: c,
          decoration: InputDecoration(labelText: label),
          validator: required
              ? (v) => (v == null || v.isEmpty) ? 'Campo obrigatorio' : null
              : null,
        ),
      );
}
