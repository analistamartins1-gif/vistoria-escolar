import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app.dart';
import 'core/di/injection.dart';

/// Ponto de entrada do aplicativo.
///
/// Fluxo de inicializacao:
/// 1. Garante que o binding do Flutter esteja pronto (necessario para acessar
///    plugins como camera, sqflite e firebase antes do runApp).
/// 2. Inicializa a camada de infraestrutura (banco local, Firebase, servicos).
/// 3. Envolve o app com [ProviderScope] (raiz do Riverpod).
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Inicializa dependencias de baixo nivel (DB local, Firebase, etc.).
  // O app continua funcionando mesmo se o Firebase falhar (modo offline).
  await bootstrap();

  runApp(
    const ProviderScope(
      child: VistoriaApp(),
    ),
  );
}
