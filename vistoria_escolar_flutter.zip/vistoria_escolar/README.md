# Vistoria Escolar — App de Levantamento Técnico de Reformas

Aplicativo **Flutter** (Android como prioridade, iOS na sequência) para levantamento técnico de reformas de escolas municipais. Substitui o levantamento manual em campo: funciona **100% offline** (SQLite) e **sincroniza com o Firebase** quando há internet.

O diferencial é o **Modo IA/AR**: o engenheiro/arquiteto percorre o ambiente com a câmera e o app identifica o ambiente, mede paredes por Realidade Aumentada, detecta itens e patologias, e calcula os quantitativos automaticamente — sempre indicando o **nível de confiança** de cada medida.

> **Aviso técnico (contratação pública):** as medições por câmera/AR são **estimativas**. O app sempre exibe o nível de confiança e permite conferência/edição manual. Para quantitativos de projeto e orçamento, **valide com trena, trena a laser ou planta existente**.

---

## Como rodar

Pré-requisitos: Flutter 3.19+ / Dart 3.3+, Android Studio (SDK Android) e um dispositivo com **ARCore** (Android) para o Modo AR.

    flutter pub get
    flutter run                 # dispositivo Android conectado
    flutter test                # roda os testes (inclui o motor de quantificação)
    flutter build apk --release # gera o APK

### Firebase (sincronização)
1. Crie um projeto no Firebase e rode `flutterfire configure` (gera `firebase_options.dart`).
2. Descomente a inicialização do Firebase em `lib/core/di/injection.dart` (`bootstrap()`).
3. Adicione `google-services.json` em `android/app/`.

### Modelos de IA
Coloque os modelos treinados em `assets/models/`:
- `items.tflite` — detecção de portas, janelas, luminárias, tomadas, etc.
- `pathologies.tflite` — classificação de patologias (fissura, infiltração, mofo…).
- `environment.tflite` — classificação do tipo de ambiente.

Os serviços já mapeiam os rótulos (labels) para o domínio; basta plugar os arquivos e o carregamento nos `TODO(prod)`.

### Permissões
Câmera, microfone (áudio→texto), localização (GPS), armazenamento. Declare em `AndroidManifest.xml` e `Info.plist`.

---

## Arquitetura (Clean Architecture + SOLID)

    lib/
    ├── main.dart                     # entrada; bootstrap() + ProviderScope
    ├── app.dart                      # MaterialApp, tema claro/escuro
    ├── core/
    │   ├── theme/                    # tema (botões grandes, claro/escuro)
    │   ├── constants/                # enums de domínio, constantes
    │   ├── di/injection.dart         # GetIt + providers Riverpod
    │   ├── error/failures.dart       # falhas tratadas
    │   ├── utils/geometry_utils.dart # geometria (Dart puro, testável)
    │   └── sync/sync_service.dart    # sincronização offline-first
    ├── features/
    │   ├── survey/                   # escola → ambiente → parede → ...
    │   │   ├── domain/               # entities, repositories, usecases
    │   │   └── data/                 # SQLite (datasources, mappers, repo)
    │   └── ai_ar/                    # >>> FOCO: Modo IA/AR <<<
    │       ├── domain/quantification_engine.dart
    │       ├── services/             # AR, detecção itens/patologias, STT
    │       └── presentation/         # tela Modo IA + controller (Riverpod)
    ├── features/report/              # gerador de relatório PDF
    └── presentation/                 # dashboard, escola, ambiente, widgets

Camadas: **Presentation** (Riverpod) → **Domain** (entidades + use cases + interfaces) → **Data** (SQLite/Firebase). A UI depende de abstrações (`SurveyRepository`), nunca da implementação (DIP).

---

## Modo IA/AR — fluxo

1. **Identifica o ambiente** (`EnvironmentClassifierService`).
2. **Mede paredes e piso** por AR (`ArMeasurementService`) com nível de confiança.
3. **Detecta itens** (`ObjectDetectionService` / ML Kit + TFLite).
4. **Detecta patologias** (`PathologyDetectionService`).
5. **Quantifica** (`QuantificationEngine`).
6. **Revisa e confirma** — medidas de baixa confiança são destacadas.

O `AiScanController` (StateNotifier) orquestra as etapas mantendo a tela apenas como renderizador de estado.

---

## Motor de quantificação (núcleo técnico)

`QuantificationEngine` é **Dart puro** e testado (`test/quantification_engine_test.dart`). Coeficientes em `QuantificationParams`:

| Material | Coeficiente padrão | Base |
|---|---|---|
| Tinta | 10 m²/L por demão, 2 demãos | pintura líquida (bruta − aberturas) |
| Selador | 8 m²/L, 1 demão | área líquida de parede |
| Massa corrida | 0,45 kg/m² por demão, 2 demãos | área líquida de parede |
| Piso / Revestimento | +10% de perda | área medida |

Exemplo validado (sala 6×5 m, pé-direito 3 m, 1 porta): pintura = **64,11 m²**, tinta = **12,82 L**, rodapé = **22,0 m**, piso = **33,0 m²** (com perda).

> Ajuste os coeficientes conforme SINAPI/SICRO e fichas técnicas antes de usar em orçamento oficial.

---

## Status desta entrega

Esqueleto funcional e coeso: domínio, banco SQLite offline, Riverpod/DI, Modo IA/AR (serviços + tela + controller), motor de quantificação testado, sugestão de serviços/risco, relatório PDF, sincronização e dashboard.

Pontos marcados com `TODO(prod)` são as integrações de hardware/nuvem que exigem device real e chaves: carregamento dos modelos `.tflite`, sessão AR do plugin, envio ao Firestore/Storage. A lógica de negócio ao redor já está pronta e testável.
