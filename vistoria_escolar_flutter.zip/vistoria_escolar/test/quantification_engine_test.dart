import 'package:flutter_test/flutter_test.dart';
import 'package:vistoria_escolar/core/constants/enums.dart';
import 'package:vistoria_escolar/features/survey/domain/entities/environment.dart';
import 'package:vistoria_escolar/features/survey/domain/entities/wall.dart';
import 'package:vistoria_escolar/features/survey/domain/entities/measurement.dart';
import 'package:vistoria_escolar/features/survey/domain/entities/detected_item.dart';
import 'package:vistoria_escolar/features/ai_ar/domain/quantification_engine.dart';

void main() {
  group('QuantificationEngine', () {
    // Sala de aula 6.00 x 5.00, pe-direito 3.00, 1 porta (2.10x0.90=1.89 m2).
    // 4 paredes: 2 de 6.00m e 2 de 5.00m, altura 3.00m.
    Environment buildSala() {
      Wall wall(String id, double w, {double openings = 0}) => Wall(
            id: id,
            environmentId: 'e1',
            label: id,
            openingsAreaM2: openings,
            measurement: const Measurement(
              widthM: 0,
              heightM: 3.0,
              confidence: ConfidenceLevel.manual,
            ).copyWith(widthM: w),
          );

      return Environment(
        id: 'e1',
        schoolId: 's1',
        code: 'SALA 01',
        type: EnvironmentType.salaDeAula,
        floorAreaM2: 30.0, // 6 x 5
        walls: [
          wall('P1', 6.0, openings: 1.89), // parede com porta
          wall('P2', 6.0),
          wall('P3', 5.0),
          wall('P4', 5.0),
        ],
      );
    }

    test('areas de parede, pintura e piso', () {
      const engine = QuantificationEngine();
      final q = engine.compute(buildSala(), const []);

      // Area bruta de paredes = (6+6+5+5) * 3 = 66 m2.
      // Pintura liquida = 66 - 1.89 (porta) = 64.11 m2.
      expect(q.paintAreaM2, closeTo(64.11, 0.01));

      // Piso com 10% de perda = 30 * 1.10 = 33.0 m2.
      expect(q.floorAreaM2, closeTo(33.0, 0.01));

      // Forro = area de piso (tem forro) = 30.0 m2 (sem perda).
      expect(q.ceilingAreaM2, closeTo(30.0, 0.01));

      // Rodape = soma das larguras (todas com rodape) = 22.0 m.
      expect(q.baseboardLengthM, closeTo(22.0, 0.01));
    });

    test('consumo de tinta com 2 demaos e rendimento 10 m2/L', () {
      const engine = QuantificationEngine();
      final q = engine.compute(buildSala(), const []);
      // Tinta = 64.11 * 2 / 10 = 12.82 L.
      expect(q.paintLiters, closeTo(12.82, 0.05));
    });

    test('contagem de itens detectados', () {
      const engine = QuantificationEngine();
      final items = [
        const DetectedItem(
          id: 'i1',
          environmentId: 'e1',
          type: ItemType.porta,
          quantity: 1,
          confidence: ConfidenceLevel.alta,
        ),
        const DetectedItem(
          id: 'i2',
          environmentId: 'e1',
          type: ItemType.janela,
          quantity: 2,
          confidence: ConfidenceLevel.media,
        ),
      ];
      final q = engine.compute(buildSala(), items);
      expect(q.doors, 1);
      expect(q.windows, 2);
    });
  });
}
